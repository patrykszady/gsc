<?php

namespace SsSystems\Platform\Reports\Contracts;

/**
 * The site's own public shape: where it lives, and what it publishes.
 *
 * Capability key: `site_catalog`.
 */
interface SiteCatalog
{
    /**
     * rtrim(config('app.url'), '/') on every one of the ten commands that
     * self-crawl. Used to build the sitemap URL, landing-page URLs
     * (SeoGbpParity's --landing-pages), and area-page URLs
     * (SeoAreaPagesAudit's variant paths).
     */
    public function baseUrl(): string;

    /**
     * parse_url(baseUrl(), PHP_URL_HOST) — only SeoHealthCheck uses this,
     * to decide whether an absolute href points back at this site (its
     * internal-link count).
     */
    public function canonicalHost(): string;

    /**
     * Every <loc> URL in this site's own sitemap.xml, trimmed, deduplicated,
     * in document order — UNFILTERED (media/xml/txt entries and all).
     *
     * SeoGbpParity, SeoInternalLinkSuggest, SeoSchemaAudit and
     * SeoHealthCheck each fetch {baseUrl}/sitemap.xml and regex-extract
     * <loc> themselves today; three of the four then apply their OWN
     * extension-filter before slicing to their own --limit, and the
     * filters differ between commands (see docs/REPORTS-PORTING.md's table).
     * A ported report re-applies its OWN original filter/limit to this same
     * unfiltered list rather than the kit picking one filter for everyone.
     *
     * A network failure or unparseable response returns [], exactly like
     * each command's own try/catch(\Throwable) around the sitemap fetch
     * does today.
     *
     * @return list<string>
     */
    public function sitemapUrls(): array;
}
