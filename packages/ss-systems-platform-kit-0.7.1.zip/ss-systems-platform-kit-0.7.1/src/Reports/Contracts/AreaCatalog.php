<?php

namespace SsSystems\Platform\Reports\Contracts;

/**
 * What SeoHealth's on-page pillar and SeoAreaPagesAudit read from
 * AreaServed — a site's per-city/area landing pages. A site with no such
 * page architecture (no AreaServed-equivalent) returns [] and both reports
 * read that as "not applicable here", never as zero content on real pages.
 *
 * Capability key: `area_catalog`.
 */
interface AreaCatalog
{
    /**
     * Every service-area landing page this site has.
     *
     * content_complete mirrors SeoHealth::scoreOnPage()'s exact check —
     * intro, local_intro and landmarks all non-null and non-empty — so the
     * on-page health pillar and SeoAreaPagesAudit's sampling both read from
     * ONE method instead of two slightly different area queries.
     *
     * @return list<array{id: int, slug: string, city: ?string, content_complete: bool}>
     */
    public function areas(): array;
}
