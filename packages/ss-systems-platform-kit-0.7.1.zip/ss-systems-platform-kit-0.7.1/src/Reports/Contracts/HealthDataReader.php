<?php

namespace SsSystems\Platform\Reports\Contracts;

/**
 * Every OTHER read SeoHealth makes, beyond AreaCatalog (on-page area
 * completeness) and QueryMetricsReader (the local-rankings pillar's
 * all-pages-visibility sub-score): image/social counts, crawl-log
 * freshness, the rank tracker, and the health-score ledger itself.
 *
 * Capability key: `health_data`.
 */
interface HealthDataReader
{
    /**
     * Alt-text coverage across PUBLISHED projects' images only — the other
     * half of the on-page pillar (paired with AreaCatalog's content-depth
     * half). @return array{total: int, with_alt: int}
     */
    public function imageAltCoverage(): array;

    /**
     * storage_path('logs/seo-internal-links.log')'s mtime, or null when
     * the internal-link audit has never run for this site — the
     * internal-linking pillar (SeoHealth::scoreInternalLinks()).
     */
    public function internalLinkAuditLastRunAt(): ?\DateTimeInterface;

    /**
     * GBP activity: Google Business posts published in the last 7/30 days;
     * whether one has EVER been published (a tenant with no GBP pipeline at
     * all must read as "not measured", never "neglected" — see
     * SeoHealth::scoreGbpActivity()'s own comment on this); and the same
     * shape for photo uploads in the last 90 days. photos_last_90 is null
     * and ever_uploaded is false on a site with no image-upload tracking
     * table at all (gsc's Schema::hasTable('image_platform_uploads') guard
     * becomes the adapter's job, not the report's).
     *
     * @return array{posts_last_7: int, posts_last_30: int, ever_posted: bool, photos_last_90: ?int, ever_uploaded: bool}
     */
    public function gbpActivity(): array;

    /**
     * The LATEST snapshot per (engine, query, location) from this site's
     * rank tracker (seo_rank_snapshots) — [] on a site with no rank-tracking
     * table at all. Mirrors SeoHealth::scoreLocalRankings()'s self-join
     * query.
     *
     * @return list<array{engine: string, position: ?float}>
     */
    public function latestRankSnapshots(): array;

    /**
     * mtimes of the three freshness signals SeoHealth checks, keyed EXACTLY
     * as the report's own table/markdown expects. A tenant whose pipeline
     * has never run has null for that key — the key itself is always
     * present.
     *
     * @return array{"sitemap.xml": ?\DateTimeInterface, "gsc-sync log": ?\DateTimeInterface, "gbp-metrics-sync log": ?\DateTimeInterface}
     */
    public function freshnessSignals(): array;

    /**
     * The health-score ledger: calendar date ('Y-m-d') => 0-100 score, one
     * entry per day, in whatever order storage returns it (the report sorts
     * and prunes to 120). [] for a site that has never run the health
     * report before. See SeoHealth::appendHealthLedger()'s own docblock for
     * why this is tenant-scoped storage rather than a DB table.
     *
     * @return array<string, int>
     */
    public function healthLedger(): array;

    /**
     * Persist the ledger — already merged with today's score, sorted, and
     * pruned to the newest 120 entries by the report itself (the kit owns
     * that algorithm; storage just holds what it is given).
     *
     * @param  array<string, int>  $ledger
     */
    public function putHealthLedger(array $ledger): void;
}
