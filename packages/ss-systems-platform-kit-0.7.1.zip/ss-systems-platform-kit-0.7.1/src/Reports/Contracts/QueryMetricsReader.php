<?php

namespace SsSystems\Platform\Reports\Contracts;

/**
 * The aggregations SeoContentDecay and SeoContentGap run over
 * gsc_query_metrics — one row per (date, query, page, country, device),
 * written by SearchConsoleSync (see Seo\SearchConsoleSync in this kit).
 *
 * Capability key: `query_metrics`.
 */
interface QueryMetricsReader
{
    /**
     * Impressions/clicks/impression-weighted-average-position per PAGE for
     * the closed date window [$from, $to] (both 'Y-m-d'), rounded to 2
     * decimals — exactly SeoContentDecay::aggregate(). Used by
     * ContentDecayReport for its recent-vs-prior comparison, and reusable
     * by HealthReport's local-rankings pillar for its "all-pages visibility"
     * sub-score (SeoHealth's own query additionally filters out null/empty
     * `page` and requires impressions > 0 — apply that filtering in the
     * report, not here, since SeoContentDecay's aggregate() does not).
     *
     * @return list<array{page: string, impressions: int, clicks: int, position: ?float}>
     */
    public function pageMetrics(string $from, string $to): array;

    /**
     * Impressions/clicks/impression-weighted-average-position per
     * (query, page) pair, only rows with >= $minImpressions total
     * impressions in the window — exactly SeoContentGap's grouped query.
     * Position is NOT pre-rounded (SeoContentGap rounds to 2 decimals
     * itself after receiving it).
     *
     * @return list<array{query: string, page: string, impressions: int, clicks: int, position: float}>
     */
    public function queryPageMetrics(string $from, string $to, int $minImpressions): array;
}
