<?php

namespace SsSystems\Platform\Reports\Contracts;

/**
 * Everything SeoClarityHealth reads: whether Microsoft Clarity is
 * configured, a live call to its Data Export API, the stored
 * clarity_daily_metrics rows, and the on-site JS-error beacon
 * (ClientError) that corroborates or debunks a script-error spike.
 *
 * Capability key: `clarity_metrics`.
 */
interface ClarityMetricsReader
{
    public function isConfigured(): bool;

    public function projectId(): ?string;

    /**
     * A live call to Clarity's Data Export API (project-live-insights,
     * <= 3 days — MicrosoftClarityService::MAX_DAYS). Null + lastError()
     * set on ANY failure: missing token, network error, rate limit,
     * unexpected payload shape — the report never learns which.
     *
     * @return array{date: string, sessions: int, users: int, pageviews: int, scroll_depth: float, active_time_seconds: int, bounce_rate: float, dead_clicks: int, rage_clicks: int, quickbacks: int, script_errors: int, error_clicks: int}|null
     */
    public function fetchLiveSnapshot(): ?array;

    public function lastError(): ?string;

    /**
     * The most recently stored day for this project, or null when nothing
     * has ever synced.
     *
     * @return array{date: string, sessions: int, users: int, pageviews: int, scroll_depth: float, active_time_seconds: int, bounce_rate: float, dead_clicks: int, rage_clicks: int, quickbacks: int, script_errors: int, error_clicks: int}|null
     */
    public function latestStoredMetric(): ?array;

    public function storedRowCount(): int;

    /**
     * Up to $limit stored days strictly BEFORE $beforeDate ('Y-m-d'),
     * most-recent first — the trailing baseline
     * SeoClarityHealth::detectScriptErrorSpike() compares the latest day's
     * error rate against.
     *
     * @return list<array{sessions: int, script_errors: int}>
     */
    public function baselineMetrics(string $beforeDate, int $limit): array;

    /**
     * ClientError rows (the on-site JS-error beacon) seen since $since —
     * corroborates or debunks a Clarity script-error spike (Clarity counts
     * every script error including cross-origin noise the beacon
     * deliberately drops).
     */
    public function beaconErrorCount(\DateTimeInterface $since): int;
}
