<?php

namespace SsSystems\Platform\Reports;

use Illuminate\Support\Carbon;
use Psr\SimpleCache\CacheInterface;
use SsSystems\Platform\Reports\Contracts\QueryMetricsReader;

/**
 * Content-decay detector — ported verbatim from gs.construction's
 * app/Console/Commands/SeoContentDecay.php (same thresholds, same markdown
 * text and heading order, same row ordering; this is a transcription, not a
 * redesign). The reference port for docs/REPORTS-PORTING.md.
 *
 * Compares the most recent `window` days against the immediately-preceding
 * `window` days and surfaces pages whose clicks dropped by >= `click_drop`
 * percent, or whose average position regressed by >= `pos_drop`, beyond the
 * `min_impressions` noise floor. Aggregates at the PAGE level
 * (impression-weighted position) via QueryMetricsReader::pageMetrics().
 *
 * The original command also decided, via a 30-hour Cache::add() dedup key,
 * whether to log a warning/info line about the day's regressions, and at
 * which of three levels: suppressed (already logged today), a meaningful
 * regression (some page lost >= 5 clicks), or low-volume churn only. The
 * kit has no logger of its own — pure PHP, no Laravel `logger()` helper —
 * so that three-way decision travels in `ReportResult::data['alert']`
 * instead of being logged directly; the site's thin artisan wrapper reads
 * it and calls logger() itself. This is the one place this port could not
 * be a pure 1:1 transcription, because the original behaviour (deciding
 * AND emitting a log line) crosses a boundary this design deliberately
 * keeps the kit on the far side of. See docs/REPORTS-PORTING.md.
 */
final class ContentDecayReport implements Report
{
    public function __construct(
        private readonly QueryMetricsReader $queryMetrics,
        private readonly CacheInterface $cache,
    ) {
    }

    public static function key(): string
    {
        return 'content-decay';
    }

    /** @return list<string> */
    public static function requires(): array
    {
        return ['query_metrics', 'cache'];
    }

    public function generate(array $options = []): ReportResult
    {
        $window = max(1, (int) ($options['window'] ?? 28));
        $minImpressions = max(1, (int) ($options['min_impressions'] ?? 50));
        $clickDropPct = max(1, (int) ($options['click_drop'] ?? 20));
        $posDrop = (float) ($options['pos_drop'] ?? 2);
        $limit = max(1, (int) ($options['limit'] ?? 40));

        $end = Carbon::today();
        $recentStart = $end->copy()->subDays($window - 1);
        $priorEnd = $recentStart->copy()->subDay();
        $priorStart = $priorEnd->copy()->subDays($window - 1);

        $recent = $this->aggregate($recentStart, $end);
        $prior = $this->aggregate($priorStart, $priorEnd);

        $rows = [];
        foreach ($prior as $page => $p) {
            if ($p['impressions'] < $minImpressions) {
                continue;
            }

            $r = $recent[$page] ?? ['impressions' => 0, 'clicks' => 0, 'position' => null];
            $clickDelta = $r['clicks'] - $p['clicks'];
            $clickPct = $p['clicks'] > 0 ? ($clickDelta / $p['clicks']) * 100 : 0;
            $posDelta = ($r['position'] !== null && $p['position'] !== null)
                ? $r['position'] - $p['position']
                : null;

            $rows[] = [
                'page' => $page,
                'p_clicks' => $p['clicks'], 'r_clicks' => $r['clicks'], 'click_pct' => $clickPct,
                'p_pos' => $p['position'], 'r_pos' => $r['position'], 'pos_delta' => $posDelta,
            ];
        }

        $clickDecay = array_values(array_filter(
            $rows,
            fn (array $r): bool => $r['p_clicks'] > 0 && $r['click_pct'] <= -$clickDropPct,
        ));
        usort($clickDecay, fn (array $a, array $b) => $a['click_pct'] <=> $b['click_pct']);
        $clickDecay = array_slice($clickDecay, 0, $limit);

        $posDecay = array_values(array_filter(
            $rows,
            fn (array $r): bool => $r['pos_delta'] !== null && $r['pos_delta'] >= $posDrop,
        ));
        usort($posDecay, fn (array $a, array $b) => $b['pos_delta'] <=> $a['pos_delta']);
        $posDecay = array_slice($posDecay, 0, $limit);

        $markdown = $this->buildMarkdown($clickDecay, $posDecay, $recentStart, $end, $priorStart, $priorEnd);
        $summary = sprintf('%d click drop(s), %d position regression(s).', count($clickDecay), count($posDecay));

        $data = [
            'click_drops' => count($clickDecay),
            // A 1-2 click page dropping to 0 is statistical noise, not decay — count
            // only drops from a meaningful click base (>= 5) toward the WARNING level
            // (the full list still lands in click_decay/the markdown either way).
            'meaningful_click_drops' => count(array_filter($clickDecay, fn (array $r): bool => $r['p_clicks'] >= 5)),
            'pos_regressions' => count($posDecay),
            'click_decay' => $clickDecay,
            'pos_decay' => $posDecay,
        ];
        $data['alert'] = $this->alert($data);

        return ReportResult::ok($markdown, $summary, $data);
    }

    /**
     * @return array<string, array{impressions: int, clicks: int, position: ?float}>
     */
    private function aggregate(Carbon $from, Carbon $to): array
    {
        $out = [];
        foreach ($this->queryMetrics->pageMetrics($from->toDateString(), $to->toDateString()) as $row) {
            $out[$row['page']] = [
                'impressions' => $row['impressions'],
                'clicks' => $row['clicks'],
                'position' => $row['position'],
            ];
        }

        return $out;
    }

    /**
     * Decides whether today's regressions were already reported (suppressed
     * for 30 hours, same as the original Cache::add() dedup key), and at
     * which level — mirrors the original command's three-way branch
     * exactly, just returning the decision instead of calling logger().
     *
     * @param  array{click_drops: int, meaningful_click_drops: int, pos_regressions: int}  $data
     * @return array{suppressed: bool, level: ?string, message: ?string}
     */
    private function alert(array $data): array
    {
        if ($data['click_drops'] === 0 && $data['pos_regressions'] === 0) {
            return ['suppressed' => false, 'level' => null, 'message' => null];
        }

        $summary = [
            'click_drops' => $data['click_drops'],
            'meaningful_click_drops' => $data['meaningful_click_drops'],
            'pos_regressions' => $data['pos_regressions'],
        ];

        $cacheKey = 'seo:content-decay:warn:'.Carbon::now()->format('Ymd').':'.md5((string) json_encode($summary));

        if ($this->cache->has($cacheKey)) {
            return [
                'suppressed' => true,
                'level' => 'info',
                'message' => 'seo:content-decay repeated regressions suppressed',
            ];
        }

        // 30 hours, exactly like the original's Cache::add($cacheKey, true, now()->addHours(30)).
        $this->cache->set($cacheKey, true, 30 * 3600);

        if ($data['meaningful_click_drops'] > 0) {
            return ['suppressed' => false, 'level' => 'warning', 'message' => 'seo:content-decay found regressions'];
        }

        return [
            'suppressed' => false,
            'level' => 'info',
            'message' => 'seo:content-decay: low-volume churn only (no page lost 5+ clicks)',
        ];
    }

    /**
     * @param  list<array{page: string, p_clicks: int, r_clicks: int, click_pct: float}>  $clickDecay
     * @param  list<array{page: string, p_pos: ?float, r_pos: ?float, pos_delta: float}>  $posDecay
     */
    private function buildMarkdown(array $clickDecay, array $posDecay, Carbon $rs, Carbon $re, Carbon $ps, Carbon $pe): string
    {
        $md = "# Content decay report\n\n";
        $md .= 'Run: '.Carbon::now()->toIso8601String()."\n\n";
        $md .= sprintf(
            "Recent window: %s..%s   Prior window: %s..%s\n\n",
            $rs->toDateString(), $re->toDateString(), $ps->toDateString(), $pe->toDateString(),
        );

        $md .= '## Click drops ('.count($clickDecay).")\n\n";
        $md .= "| Page | Prior clicks | Recent clicks | % change |\n|---|---:|---:|---:|\n";
        foreach ($clickDecay as $r) {
            $md .= sprintf("| %s | %d | %d | %+.1f%% |\n", $r['page'], $r['p_clicks'], $r['r_clicks'], $r['click_pct']);
        }

        $md .= "\n## Position regressions (".count($posDecay).")\n\n";
        $md .= "| Page | Prior pos | Recent pos | Δ pos |\n|---|---:|---:|---:|\n";
        foreach ($posDecay as $r) {
            $md .= sprintf(
                "| %s | %s | %s | %+.2f |\n",
                $r['page'],
                $r['p_pos'] !== null ? number_format($r['p_pos'], 2) : '—',
                $r['r_pos'] !== null ? number_format($r['r_pos'], 2) : '—',
                $r['pos_delta'],
            );
        }

        $md .= "\n## Action\n\nFor each page above: review on-page content for freshness, broken/dated facts, missing internal links from newer pages, and dropped queries (cross-reference with `seo:gsc-monitor`). Update last_modified after substantive edits so the sitemap reflects the change.\n";

        return $md;
    }
}
