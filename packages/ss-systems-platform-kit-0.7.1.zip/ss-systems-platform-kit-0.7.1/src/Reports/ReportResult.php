<?php

namespace SsSystems\Platform\Reports;

/**
 * What a Report::generate() call hands back — everything a site's thin
 * artisan wrapper needs to behave exactly like the original gsc command did
 * (write the markdown file, print a summary line, print the same console
 * table from `data`, and exit non-zero on `error`) without knowing anything
 * about the report's own algorithm.
 *
 * Four statuses, not a boolean:
 *   - ok         the report ran and produced a complete result.
 *   - degraded   the report ran but part of it is unmeasured (see
 *                `missing` — e.g. SeoHealth's null pillars) — still a
 *                genuine result, not a failure.
 *   - unavailable a required capability isn't bound on this site at all.
 *                ReportRegistry::availableFor() lets a site check this
 *                BEFORE calling generate() (the whole point of `requires()`
 *                — no CommandNotFoundException to catch, ever), but
 *                generate() itself may also return this if it discovers
 *                mid-run that it has nothing to report on.
 *   - error      something actually broke (a client threw, a payload was
 *                unreadable). `error` carries the message; the site logs it
 *                and shows a plain sentence, never the raw exception text,
 *                outside a Details accordion (ss-systems' own rule).
 */
final class ReportResult
{
    public const STATUS_OK = 'ok';

    public const STATUS_DEGRADED = 'degraded';

    public const STATUS_UNAVAILABLE = 'unavailable';

    public const STATUS_ERROR = 'error';

    /**
     * @param  'ok'|'degraded'|'unavailable'|'error'  $status
     * @param  list<string>  $missing  requirement/capability keys not met — [] for ok/error
     * @param  array<string, mixed>  $data  the structured findings the original command printed as a console table
     */
    private function __construct(
        public readonly string $status,
        public readonly string $markdown,
        public readonly string $summary,
        public readonly array $missing,
        public readonly ?string $error,
        public readonly array $data,
    ) {
    }

    /** @param  array<string, mixed>  $data */
    public static function ok(string $markdown, string $summary, array $data = []): self
    {
        return new self(self::STATUS_OK, $markdown, $summary, [], null, $data);
    }

    /**
     * @param  list<string>  $missing  which sub-signals were unmeasured (report-specific — e.g. SeoHealth's pillar names)
     * @param  array<string, mixed>  $data
     */
    public static function degraded(string $markdown, string $summary, array $missing = [], array $data = []): self
    {
        return new self(self::STATUS_DEGRADED, $markdown, $summary, $missing, null, $data);
    }

    /**
     * No markdown is produced — there is nothing to write. Used both by a
     * site's pre-flight `requires()` check (never calls generate() at all)
     * and by a report that discovers mid-run it has no usable data source.
     *
     * @param  list<string>  $missing  capability keys not bound, or report-specific reasons
     */
    public static function unavailable(array $missing, string $summary = ''): self
    {
        return new self(
            self::STATUS_UNAVAILABLE,
            '',
            $summary !== '' ? $summary : self::defaultUnavailableSummary($missing),
            $missing,
            null,
            [],
        );
    }

    /** @param  array<string, mixed>  $data  whatever partial findings existed before the failure, if any */
    public static function error(string $error, string $summary = '', array $data = []): self
    {
        return new self(self::STATUS_ERROR, '', $summary !== '' ? $summary : $error, [], $error, $data);
    }

    /** ok or degraded — a result a site can actually write to disk. */
    public function isSuccessful(): bool
    {
        return $this->status === self::STATUS_OK || $this->status === self::STATUS_DEGRADED;
    }

    /** @param  list<string>  $missing */
    private static function defaultUnavailableSummary(array $missing): string
    {
        return $missing === []
            ? 'Not available for this site.'
            : 'Not available for this site — missing: '.implode(', ', $missing).'.';
    }
}
