<?php

namespace SsSystems\Platform\Reports;

use Illuminate\Support\Carbon;
use SsSystems\Platform\Reports\Contracts\AreaCatalog;
use SsSystems\Platform\Reports\Contracts\HealthDataReader;
use SsSystems\Platform\Reports\Contracts\QueryMetricsReader;

/**
 * Unified SEO health dashboard — ported verbatim from gs.construction's
 * app/Console/Commands/SeoHealth.php (549 lines, the largest of the ten
 * commands). Same five pillars, same weights (each pillar contributes
 * equally — a plain average of whichever pillars actually measured
 * something), same "average only the measured pillars" rule (an unmeasured
 * pillar is null, never 0 or 100 — see each score*() method's own comment,
 * copied from the original, on why treating absence as a real score once
 * misled jpeterson-design and once left production with an empty
 * health.md), and the same health-score ledger (merge today's score,
 * chronological sort, prune to the newest 120 entries).
 *
 * Data sources, per docs/REPORTS-PORTING.md:
 *   - On-page completeness:    HealthDataReader::imageAltCoverage()  (images)
 *                             + AreaCatalog::areas()                 (areas)
 *   - Internal linking:        HealthDataReader::internalLinkAuditLastRunAt()
 *   - GBP activity:            HealthDataReader::gbpActivity()
 *   - Local rankings:          HealthDataReader::latestRankSnapshots() (rank
 *                               tracker half) + QueryMetricsReader::pageMetrics()
 *                               (GSC all-pages-visibility half), blended 0.6/0.4
 *                               exactly like the original.
 *   - Freshness:                HealthDataReader::freshnessSignals()
 *   - The ledger:                HealthDataReader::healthLedger() /
 *                               ::putHealthLedger() — the merge/sort/prune
 *                               algorithm itself stays here, in the report.
 *
 * Two places this port could not be a pure 1:1 transcription of the
 * artisan command — both explained where they happen below:
 *   1. The local-rankings pillar's GSC half re-applies SeoHealth's own
 *      extra filter (drop null/empty `page`, require impressions > 0) on
 *      top of QueryMetricsReader::pageMetrics(), per
 *      docs/REPORTS-PORTING.md's instruction not to grow a second,
 *      near-duplicate interface method for one extra WHERE clause. That
 *      also means `position` here is pre-rounded to 2 decimals (the
 *      interface's contract), where the original command's raw SQL used
 *      an unrounded weighted average — immaterial at the 3.0/10.0/20.0
 *      thresholds this pillar compares against.
 *   2. The original command's private renderReport()/saveMarkdown() type
 *      -hinted their $total parameter as a non-nullable `int`, even though
 *      handle() computes `$total` as `?int` — a tenant with literally
 *      every pillar unmeasured (a brand-new site: no images, no areas, no
 *      GBP activity ever, no crawl, no freshness signal on disk at all)
 *      would have hit a TypeError before ever printing or saving. A
 *      Report must always return a ReportResult, never throw, so this
 *      port keeps $total nullable throughout and renders "not measured
 *      yet" for the overall score exactly like every individual pillar
 *      already does — see grade() and buildMarkdown() below.
 */
final class HealthReport implements Report
{
    private const LEDGER_MAX_ENTRIES = 120;

    public function __construct(
        private readonly HealthDataReader $healthData,
        private readonly AreaCatalog $areaCatalog,
        private readonly QueryMetricsReader $queryMetrics,
    ) {
    }

    public static function key(): string
    {
        return 'health';
    }

    /** @return list<string> */
    public static function requires(): array
    {
        // area_catalog is optional: see ReportRegistry's note on this report.
        return ['health_data', 'query_metrics'];
    }

    public function generate(array $options = []): ReportResult
    {
        // quiet_on_pass has no effect on the algorithm below — same as the
        // original command, where it only ever gated whether handle() wrote
        // the markdown file / ledger entry and printed the console table.
        // Persisting markdown and printing are the SITE wrapper's job here
        // (docs/REPORTS-PORTING.md), so this report always computes and
        // returns the full result; it just echoes the flag back in `data`
        // so the wrapper can replicate `--quiet-on-pass`'s exit-code
        // suppression exactly like the original artisan command did.
        $quietOnPass = (bool) ($options['quiet_on_pass'] ?? false);

        $pillars = [
            'on_page' => $this->scoreOnPage(),
            'internal_links' => $this->scoreInternalLinks(),
            'gbp_activity' => $this->scoreGbpActivity(),
            'local_rankings' => $this->scoreLocalRankings(),
            'freshness' => $this->scoreFreshness(),
        ];

        // Average only the pillars that were actually measured. Treating an
        // unmeasured pillar as 0 (or as 100) invents a score out of absence.
        $measuredScores = array_values(array_filter(
            array_map(static fn (array $p): ?int => $p['score'], $pillars),
            static fn (?int $s): bool => $s !== null,
        ));
        $total = $measuredScores === []
            ? null
            : (int) round(array_sum($measuredScores) / count($measuredScores));

        $missing = array_keys(array_filter($pillars, static fn (array $p): bool => $p['score'] === null));

        if ($total !== null) {
            $this->appendHealthLedger($total);
        }

        $grade = $this->grade($total);
        $markdown = $this->buildMarkdown($total, $pillars, $grade);
        $summary = $total === null
            ? 'SEO health: not measured yet.'
            : sprintf('SEO health: %d/100 (%s).', $total, $grade);

        $data = [
            'score' => $total,
            'grade' => $grade,
            'quiet_on_pass' => $quietOnPass,
            'pillars' => array_map(
                static fn (string $key, array $p): array => [
                    'key' => $key,
                    'name' => $p['name'],
                    'score' => $p['score'],
                    'bar' => self::bar($p['score']),
                    'metrics' => $p['metrics'],
                    'fix' => $p['fix'],
                    'notes' => $p['notes'] ?? [],
                ],
                array_keys($pillars),
                $pillars,
            ),
        ];

        if ($missing !== []) {
            return ReportResult::degraded($markdown, $summary, $missing, $data);
        }

        return ReportResult::ok($markdown, $summary, $data);
    }

    /* ------------------------------------------------------------------ */
    /*  Pillars */
    /* ------------------------------------------------------------------ */

    /**
     * On-page: alt text coverage + AreaCatalog content depth.
     *
     * @return array{name: string, score: ?int, metrics: array<string, mixed>, fix: ?string}
     */
    private function scoreOnPage(): array
    {
        $imageCoverage = $this->healthData->imageAltCoverage();
        $totalImages = $imageCoverage['total'];
        $imagesWithAlt = $imageCoverage['with_alt'];

        $altPct = $totalImages > 0 ? (int) round($imagesWithAlt / $totalImages * 100) : 100;

        $areas = $this->areaCatalog->areas();
        $totalAreas = count($areas);
        $areasComplete = count(array_filter($areas, static fn (array $a): bool => $a['content_complete']));
        $areaPct = $totalAreas > 0 ? (int) round($areasComplete / $totalAreas * 100) : 100;

        // A tenant with no published images and no service areas has nothing
        // to measure. Scoring that 100 (the >0 fallbacks above each return 100)
        // told J. Peterson Design its on-page SEO was perfect when it has no
        // content at all.
        if ($totalImages === 0 && $totalAreas === 0) {
            return [
                'name' => 'On-page completeness',
                'score' => null,
                'metrics' => ['status' => 'no published images or service areas yet'],
                'fix' => null,
            ];
        }

        $score = (int) round(($altPct + $areaPct) / 2);

        return [
            'name' => 'On-page completeness',
            'score' => $score,
            'metrics' => [
                'image_alt_coverage' => "{$imagesWithAlt}/{$totalImages} ({$altPct}%)",
                'area_content_depth' => "{$areasComplete}/{$totalAreas} ({$areaPct}%)",
            ],
            'fix' => $score < 100 ? 'Run: php artisan ai:generate-content' : null,
        ];
    }

    /**
     * Internal links: latest counts from the link audit (best-effort, no crawl).
     *
     * @return array{name: string, score: ?int, metrics: array<string, mixed>, fix: ?string, notes?: list<string>}
     */
    private function scoreInternalLinks(): array
    {
        // Quick proxy: every published area page should be linked from at
        // least its neighbours + the areas-served index. We score based on
        // whether a crawl has ever run at all (structural check) — this was
        // a hardcoded 90 in an earlier version, the same "healthy" score for
        // every tenant on every run, whether or not a crawl had ever
        // happened. Report the truth instead: unmeasured until the audit
        // has actually run.
        $lastRunAt = $this->healthData->internalLinkAuditLastRunAt();

        if ($lastRunAt === null) {
            return [
                'name' => 'Internal linking',
                'score' => null,
                'metrics' => ['last_full_crawl' => 'never'],
                'fix' => 'Run: php artisan seo:internal-link-audit',
                'notes' => ['No crawl has run for this site yet.'],
            ];
        }

        $age = (int) abs(Carbon::now()->diffInDays(Carbon::instance($lastRunAt)));

        return [
            'name' => 'Internal linking',
            'score' => 90,
            'metrics' => [
                'last_full_crawl' => "{$age}d ago",
            ],
            'fix' => 'Schedule already runs weekly: seo:internal-link-audit',
            'notes' => ['Run `seo:internal-link-audit` weekly for live crawl data.'],
        ];
    }

    /**
     * GBP activity: recent posts + recent media uploads.
     *
     * @return array{name: string, score: ?int, metrics: array<string, mixed>, fix: ?string}
     */
    private function scoreGbpActivity(): array
    {
        $activity = $this->healthData->gbpActivity();

        // Healthy = 4+ posts in last 30 days (≈1/week).
        $postScore = min(100, (int) round($activity['posts_last_30'] / 4 * 100));

        // Photo uploads in last 90 days. photos_last_90 is null on a site
        // with no image-upload tracking table at all (the adapter's job to
        // decide, not this report's) — such a site defaults to 100, same as
        // the original command's Schema::hasTable() guard defaulted.
        $photoScore = $activity['photos_last_90'] === null
            ? 100
            : ($activity['photos_last_90'] > 0 ? 100 : 60);

        // No Google Business Profile pipeline for this tenant at all — never a
        // post, never an upload. Scoring that 30 reads as "neglecting your
        // GBP" when there is no GBP connected to neglect.
        if (! $activity['ever_posted'] && ! $activity['ever_uploaded']) {
            return [
                'name' => 'GBP activity',
                'score' => null,
                'metrics' => ['status' => 'no Google Business Profile activity recorded for this site'],
                'fix' => null,
            ];
        }

        $score = (int) round(($postScore + $photoScore) / 2);

        return [
            'name' => 'GBP activity',
            'score' => $score,
            'metrics' => array_filter([
                'posts_last_7d' => $activity['posts_last_7'],
                'posts_last_30d' => $activity['posts_last_30'],
                'photos_last_90d' => $activity['photos_last_90'],
            ], static fn ($v) => $v !== null),
            'fix' => $postScore < 100
                ? 'Weekly post scheduled Mondays 10:00 CT. Run now: php artisan social:post --platform=google_business --queue'
                : null,
        ];
    }

    /**
     * Local rankings: % of tracked queries ranking in top 10 across both
     * the rank tracker and Search Console's all-pages visibility.
     *
     * @return array{name: string, score: ?int, metrics: array<string, mixed>, fix: ?string}
     */
    private function scoreLocalRankings(): array
    {
        $queryScore = null;
        $total = 0;
        $top3 = 0;
        $top10 = 0;
        $top20 = 0;

        $latestPerQuery = $this->healthData->latestRankSnapshots();

        if ($latestPerQuery !== []) {
            $total = count($latestPerQuery);
            $top3 = count(array_filter($latestPerQuery, static fn (array $r): bool => $r['position'] !== null && $r['position'] <= 3));
            $top10 = count(array_filter($latestPerQuery, static fn (array $r): bool => $r['position'] !== null && $r['position'] <= 10));
            $top20 = count(array_filter($latestPerQuery, static fn (array $r): bool => $r['position'] !== null && $r['position'] <= 20));

            // Weighted score: top-3 worth 100, top-10 worth 60, top-20 worth 20.
            $queryScore = (int) round(
                ($top3 * 100 + ($top10 - $top3) * 60 + ($top20 - $top10) * 20) / $total
            );
        }

        // All-pages visibility (last 28 days) from Search Console page metrics.
        // QueryMetricsReader::pageMetrics() never applies SeoHealth's own
        // extra filter (null/empty `page`, impressions > 0) — that filter is
        // re-applied here, per docs/REPORTS-PORTING.md, instead of growing a
        // second near-duplicate interface method for one extra WHERE clause.
        $pageScore = null;
        $pagesTracked = 0;
        $pagesTop3 = 0;
        $pagesTop10 = 0;
        $pagesTop20 = 0;

        $from = Carbon::today()->subDays(27)->toDateString();
        $to = Carbon::today()->toDateString();

        $perPage = array_values(array_filter(
            $this->queryMetrics->pageMetrics($from, $to),
            static fn (array $r): bool => $r['page'] !== null && $r['page'] !== '' && $r['impressions'] > 0,
        ));

        if ($perPage !== []) {
            $pagesTracked = count($perPage);
            $pagesTop3 = count(array_filter($perPage, static fn (array $r): bool => $r['position'] !== null && (float) $r['position'] <= 3.0));
            $pagesTop10 = count(array_filter($perPage, static fn (array $r): bool => $r['position'] !== null && (float) $r['position'] <= 10.0));
            $pagesTop20 = count(array_filter($perPage, static fn (array $r): bool => $r['position'] !== null && (float) $r['position'] <= 20.0));

            $pageScore = (int) round(
                ($pagesTop3 * 100 + ($pagesTop10 - $pagesTop3) * 60 + ($pagesTop20 - $pagesTop10) * 20) / $pagesTracked
            );
        }

        if ($queryScore === null && $pageScore === null) {
            return [
                'name' => 'Local rankings',
                'score' => null,
                'metrics' => ['status' => 'no rank snapshots and no GSC page metrics yet'],
                'fix' => 'Run: php artisan seo:track-rankings --engine=both and ensure seo:gsc-sync is scheduled.',
            ];
        }

        $score = match (true) {
            $queryScore !== null && $pageScore !== null => (int) round(($queryScore * 0.6) + ($pageScore * 0.4)),
            $queryScore !== null => (int) $queryScore,
            default => (int) $pageScore,
        };

        $metrics = [];
        if ($queryScore !== null && $total > 0) {
            $metrics['queries_tracked'] = $total;
            $metrics['top_3'] = "{$top3} (".(int) round($top3 / $total * 100).'%)';
            $metrics['top_10'] = "{$top10} (".(int) round($top10 / $total * 100).'%)';
            $metrics['top_20'] = "{$top20} (".(int) round($top20 / $total * 100).'%)';
            $metrics['query_tracker_score'] = $queryScore;
        }
        if ($pageScore !== null && $pagesTracked > 0) {
            $metrics['pages_tracked_28d'] = $pagesTracked;
            $metrics['pages_top_3_28d'] = "{$pagesTop3} (".(int) round($pagesTop3 / $pagesTracked * 100).'%)';
            $metrics['pages_top_10_28d'] = "{$pagesTop10} (".(int) round($pagesTop10 / $pagesTracked * 100).'%)';
            $metrics['pages_top_20_28d'] = "{$pagesTop20} (".(int) round($pagesTop20 / $pagesTracked * 100).'%)';
            $metrics['all_pages_score_28d'] = $pageScore;
        }

        return [
            'name' => 'Local rankings',
            'score' => $score,
            'metrics' => $metrics,
            'fix' => (($queryScore !== null && $top10 < $total * 0.3) || ($pageScore !== null && $pagesTop10 < $pagesTracked * 0.3))
                ? 'Low local visibility outside HQ. Focus on per-city backlinks, real reviews mentioning city names, and GBP service-area expansion.'
                : null,
        ];
    }

    /**
     * Freshness: when did sitemap, GSC, GBP last run?
     *
     * @return array{name: string, score: ?int, metrics: array<string, mixed>, fix: ?string}
     */
    private function scoreFreshness(): array
    {
        $signals = $this->healthData->freshnessSignals();

        $metrics = [];
        $scoreSum = 0;
        $scoreCount = 0;
        foreach ($signals as $label => $mtime) {
            $age = $mtime !== null ? (int) abs(Carbon::now()->diffInDays(Carbon::instance($mtime))) : null;
            $metrics[$label] = $age === null ? 'missing' : "{$age}d ago";
            // Score: 0d=100, 7d=70, 30d=0
            $scoreSum += $age === null ? 0 : max(0, (int) round(100 - ($age * 100 / 30)));
            $scoreCount++;
        }

        // Nothing on disk at all = pipelines have never run for this tenant.
        // That is "not measured", not "stale" — a 0 would read as neglect.
        $anyPresent = false;
        foreach ($metrics as $v) {
            if ($v !== 'missing') {
                $anyPresent = true;
                break;
            }
        }

        if (! $anyPresent) {
            return [
                'name' => 'Freshness',
                'score' => null,
                'metrics' => $metrics,
                'fix' => 'No sync has run for this site yet.',
            ];
        }

        return [
            'name' => 'Freshness',
            'score' => $scoreCount > 0 ? (int) round($scoreSum / $scoreCount) : 0,
            'metrics' => $metrics,
            'fix' => 'Ensure scheduler is running (php artisan schedule:work or systemd timer).',
        ];
    }

    /* ------------------------------------------------------------------ */
    /*  Helpers */
    /* ------------------------------------------------------------------ */

    /**
     * Append today's overall score to the health ledger (one entry per
     * calendar day, last write wins), pruned to the newest 120 entries.
     * Best effort: the ledger is a nice-to-have trend line, not the report
     * itself, so any failure here is swallowed rather than failing the
     * whole report — exactly like the original command's own comment on
     * appendHealthLedger().
     */
    private function appendHealthLedger(int $total): void
    {
        try {
            $ledger = $this->healthData->healthLedger();
            $ledger[Carbon::now()->toDateString()] = $total;

            // Chronological order so pruning below drops the oldest days,
            // regardless of the order entries were originally stored in.
            ksort($ledger);

            if (count($ledger) > self::LEDGER_MAX_ENTRIES) {
                $ledger = array_slice($ledger, -self::LEDGER_MAX_ENTRIES, null, true);
            }

            $this->healthData->putHealthLedger($ledger);
        } catch (\Throwable) {
            // Best effort — never fail the health report over the ledger.
        }
    }

    /**
     * @param  array<string, array{name: string, score: ?int, metrics: array<string, mixed>, fix: ?string, notes?: list<string>}>  $pillars
     */
    private function buildMarkdown(?int $total, array $pillars, string $grade): string
    {
        $md = "# SEO Health\n\n";
        $md .= 'Run: '.Carbon::now()->toIso8601String()."\n\n";
        $md .= 'Overall score: **'.($total === null ? 'not measured yet' : "{$total}/100")."** ({$grade})\n\n";
        $md .= "| Pillar | Score |\n|---|---:|\n";

        foreach ($pillars as $pillar) {
            $md .= '| '.$pillar['name'].' | '.($pillar['score'] === null ? 'not measured yet' : (int) $pillar['score'])." |\n";
        }

        foreach ($pillars as $pillar) {
            $md .= "\n## {$pillar['name']} (".($pillar['score'] === null ? 'not measured yet' : "{$pillar['score']}/100").")\n\n";
            foreach (($pillar['metrics'] ?? []) as $key => $value) {
                $md .= '- '.$key.': '.$value."\n";
            }
            if (! empty($pillar['fix'])) {
                $md .= '- Recommended fix: '.$pillar['fix']."\n";
            }
            if (! empty($pillar['notes']) && is_array($pillar['notes'])) {
                foreach ($pillar['notes'] as $note) {
                    $md .= '- Note: '.$note."\n";
                }
            }
        }

        return $md;
    }

    /**
     * Not scored yet is not one of the original command's grades — that
     * command could never reach this branch without a TypeError (see the
     * class docblock's second deviation note). It reuses the same "not
     * measured yet" wording every unmeasured pillar already uses.
     */
    private function grade(?int $s): string
    {
        if ($s === null) {
            return 'Not scored yet';
        }

        return match (true) {
            $s >= 90 => 'A — Excellent',
            $s >= 80 => 'B — Good',
            $s >= 70 => 'C — Acceptable',
            $s >= 60 => 'D — Needs work',
            default => 'F — Critical',
        };
    }

    /**
     * An unmeasured pillar (null, never 0) draws an empty bar — the original
     * command used to crash here on the first null, which is why production
     * had no health.md at all until this was fixed (2026-09-22).
     */
    private static function bar(?int $s): string
    {
        if ($s === null) {
            return str_repeat('░', 20);
        }

        $filled = max(0, min(20, (int) round($s / 5)));

        return str_repeat('▓', $filled).str_repeat('░', 20 - $filled);
    }
}
