<?php

namespace SsSystems\Platform\Reports;

use Illuminate\Support\Carbon;
use SsSystems\Platform\Reports\Contracts\PsiSnapshotReader;

/**
 * Per-template Core Web Vitals tracker — ported verbatim from
 * gs.construction's app/Console/Commands/SeoCwvTemplate.php (same
 * thresholds, same markdown text and heading order, same row ordering;
 * this is a transcription, not a redesign).
 *
 * Classifies psi_snapshots URLs into templates (home / service / area /
 * project / review / other) via URL patterns and aggregates p75 LCP, INP,
 * CLS plus Lighthouse perf scores for each template + strategy bucket over
 * a recent window and the immediately-preceding window of the same length.
 * Surfaces regressions per template + strategy, gated on both windows
 * having at least `min_samples` snapshots so a p75 derived from a handful
 * of samples doesn't produce false alerts.
 *
 * LCP uses field (CrUX) data when present, falling back to lab (Lighthouse)
 * LCP; a bucket with no field data at all uses a more tolerant, relative
 * threshold (`lab_lcp_regress` vs. 15% of the prior p75) because throttled
 * mobile emulation is noisy. This is pure read-only aggregation against
 * whatever PsiSnapshotReader::snapshots() returns for each window — no
 * date filtering happens inside the report; the interface hands back rows
 * already scoped to the requested [from, to] range, exactly like
 * QueryMetricsReader::pageMetrics().
 *
 * The original command unconditionally called `logger()->warning()` when
 * any alert fired (no Cache::add() dedup, unlike SeoContentDecay) — so
 * unlike ContentDecayReport, no cache capability is needed here; the same
 * three-key `data['alert']` shape is produced (`suppressed` always false)
 * purely so a site's thin wrapper can treat every report's alert the same
 * way. See docs/REPORTS-PORTING.md.
 */
final class CwvTemplateReport implements Report
{
    public function __construct(
        private readonly PsiSnapshotReader $psiSnapshots,
    ) {
    }

    public static function key(): string
    {
        return 'cwv-template';
    }

    /** @return list<string> */
    public static function requires(): array
    {
        return ['psi_snapshots'];
    }

    public function generate(array $options = []): ReportResult
    {
        $win = max(1, (int) ($options['window'] ?? 7));
        $today = Carbon::today();
        $rStart = $today->copy()->subDays($win - 1);
        $pEnd = $rStart->copy()->subDay();
        $pStart = $pEnd->copy()->subDays($win - 1);

        $recent = $this->aggregateWindow($rStart, $today);
        $prior = $this->aggregateWindow($pStart, $pEnd);

        $minSamples = max(1, (int) ($options['min_samples'] ?? 10));
        $lcpRegress = (int) ($options['lcp_regress'] ?? 150);
        $labLcpRegress = (int) ($options['lab_lcp_regress'] ?? 500);
        $inpRegress = (int) ($options['inp_regress'] ?? 40);
        $clsRegress = (float) ($options['cls_regress'] ?? 0.02);

        $rows = [];
        $alerts = [];
        foreach ($recent as $key => $r) {
            [$template, $strategy] = explode('|', $key, 2);
            $p = $prior[$key] ?? null;
            $lcpΔ = ($p && $p['lcp']) ? $r['lcp'] - $p['lcp'] : null;
            $inpΔ = ($p && $p['inp']) ? $r['inp'] - $p['inp'] : null;
            $clsΔ = ($p && $p['cls'] !== null) ? round($r['cls'] - $p['cls'], 3) : null;
            $perfΔ = ($p && $p['perf'] !== null) ? $r['perf'] - $p['perf'] : null;

            $rows[] = compact('template', 'strategy') + [
                'samples' => $r['samples'],
                'lcp' => $r['lcp'], 'lcpΔ' => $lcpΔ,
                'inp' => $r['inp'], 'inpΔ' => $inpΔ,
                'cls' => $r['cls'], 'clsΔ' => $clsΔ,
                'perf' => $r['perf'], 'perfΔ' => $perfΔ,
            ];

            // Only flag regressions backed by enough data in BOTH windows; a
            // p75 derived from a handful of samples (e.g. when PSI gaps shrink a
            // bucket) swings wildly and produces false alerts.
            $enoughSamples = $r['samples'] >= $minSamples && $p && $p['samples'] >= $minSamples;
            if (! $enoughSamples) {
                continue;
            }

            // Lab-only LCP (no CrUX field data) is synthetic and noisy, so it
            // uses a more tolerant threshold than real-user field LCP — and a
            // relative floor, since ±500 ms is routine run-to-run variance on
            // throttled mobile emulation when the baseline is already 4-5s.
            $lcpThreshold = ($r['lcp_field'] ?? false)
                ? $lcpRegress
                : max($labLcpRegress, (int) round(($p['lcp'] ?? 0) * 0.15));
            if ($lcpΔ !== null && $lcpΔ >= $lcpThreshold) {
                $src = ($r['lcp_field'] ?? false) ? 'field' : 'lab';
                $alerts[] = "{$template} [{$strategy}] LCP +{$lcpΔ} ms ({$src})";
            }
            if ($inpΔ !== null && $inpΔ >= $inpRegress) {
                $alerts[] = "{$template} [{$strategy}] INP +{$inpΔ} ms";
            }
            if ($clsΔ !== null && $clsΔ >= $clsRegress) {
                $alerts[] = "{$template} [{$strategy}] CLS +{$clsΔ}";
            }
        }

        usort($rows, fn (array $a, array $b) => [$a['template'], $a['strategy']] <=> [$b['template'], $b['strategy']]);

        $markdown = $this->buildMarkdown($rows, $alerts, $rStart, $today, $pStart, $pEnd);
        $summary = sprintf('%d template row(s), %d regression alert(s).', count($rows), count($alerts));

        $data = [
            'rows' => $rows,
            'alerts' => $alerts,
        ];
        $data['alert'] = $this->alert($alerts);

        return ReportResult::ok($markdown, $summary, $data);
    }

    /**
     * @return array<string, array{samples:int, lcp_field:bool, lcp:?int, inp:?int, cls:?float, perf:?int}>
     */
    private function aggregateWindow(Carbon $from, Carbon $to): array
    {
        $rows = $this->psiSnapshots->snapshots($from->toDateString(), $to->toDateString());

        $buckets = [];
        foreach ($rows as $r) {
            $tpl = $this->classify((string) $r['url']);
            $key = $tpl.'|'.$r['strategy'];
            $buckets[$key][] = [
                // Prefer field (CrUX) when present, fall back to lab LCP.
                'lcp' => $r['field_lcp_ms'] ?? $r['lab_lcp_ms'],
                'lcp_is_field' => $r['field_lcp_ms'] !== null,
                'inp' => $r['field_inp_ms'],
                'cls' => $r['field_cls'] !== null ? (float) $r['field_cls'] : null,
                'perf' => $r['performance'],
            ];
        }

        $out = [];
        foreach ($buckets as $key => $list) {
            $fieldLcp = count(array_filter(array_column($list, 'lcp_is_field')));
            $out[$key] = [
                'samples' => count($list),
                // LCP is "field-backed" only when CrUX data exists; otherwise the
                // value is synthetic Lighthouse lab LCP, which is far noisier.
                'lcp_field' => $fieldLcp > 0,
                'lcp' => $this->p75Int(array_column($list, 'lcp')),
                'inp' => $this->p75Int(array_column($list, 'inp')),
                'cls' => $this->p75Float(array_column($list, 'cls')),
                'perf' => $this->p75Int(array_column($list, 'perf')),
            ];
        }

        return $out;
    }

    private function classify(string $url): string
    {
        $path = (string) parse_url($url, PHP_URL_PATH);

        return match (true) {
            $path === '' || $path === '/' => 'home',
            str_starts_with($path, '/services/') => 'service',
            str_starts_with($path, '/areas-served/') => 'area',
            str_starts_with($path, '/projects/') || str_starts_with($path, '/portfolio') => 'project',
            str_starts_with($path, '/testimonials') || str_starts_with($path, '/reviews') => 'review',
            default => 'other',
        };
    }

    /** @param  array<int, int|null>  $vals */
    private function p75Int(array $vals): ?int
    {
        $vals = array_values(array_filter($vals, fn ($v) => $v !== null));
        if (empty($vals)) {
            return null;
        }
        sort($vals);
        $i = (int) floor(0.75 * (count($vals) - 1));

        return (int) $vals[$i];
    }

    /** @param  array<int, float|null>  $vals */
    private function p75Float(array $vals): ?float
    {
        $vals = array_values(array_filter($vals, fn ($v) => $v !== null));
        if (empty($vals)) {
            return null;
        }
        sort($vals);
        $i = (int) floor(0.75 * (count($vals) - 1));

        return round((float) $vals[$i], 3);
    }

    private function fmt(int|float|null $v, int|float|null $d, string $unit, int $decimals = 0): string
    {
        if ($v === null) {
            return '—';
        }
        $base = $decimals > 0 ? number_format((float) $v, $decimals) : (string) $v;
        if ($unit !== '') {
            $base .= $unit;
        }
        if ($d === null) {
            return $base;
        }
        $sign = $d > 0 ? '+' : '';
        $deltaStr = $decimals > 0 ? number_format((float) $d, $decimals) : (string) $d;

        return $base.' ('.$sign.$deltaStr.')';
    }

    /**
     * Mirrors the original command's unconditional
     * `logger()->warning('seo:cwv-template regressions', ['alerts' => $alerts])`
     * call when any alert fired — the kit has no logger, so the decision
     * travels in `ReportResult::data['alert']` for the site's thin wrapper
     * to log itself, same three-key shape ContentDecayReport uses. Unlike
     * that report, the original SeoCwvTemplate has no Cache::add() dedup
     * window, so `suppressed` is always false here.
     *
     * @param  list<string>  $alerts
     * @return array{suppressed: bool, level: ?string, message: ?string}
     */
    private function alert(array $alerts): array
    {
        if (empty($alerts)) {
            return ['suppressed' => false, 'level' => null, 'message' => null];
        }

        return ['suppressed' => false, 'level' => 'warning', 'message' => 'seo:cwv-template regressions'];
    }

    /**
     * @param  list<array<string, mixed>>  $rows
     * @param  list<string>  $alerts
     */
    private function buildMarkdown(array $rows, array $alerts, Carbon $rs, Carbon $re, Carbon $ps, Carbon $pe): string
    {
        $md = "# CWV per-template report\n\n";
        $md .= 'Run: '.Carbon::now()->toIso8601String()."\n\n";
        $md .= sprintf("Recent: %s..%s   Prior: %s..%s\n\n", $rs->toDateString(), $re->toDateString(), $ps->toDateString(), $pe->toDateString());

        $md .= "## p75 metrics by template + strategy\n\n";
        $md .= "| Template | Strategy | Samples | LCP p75 (Δ) | INP p75 (Δ) | CLS p75 (Δ) | Perf (Δ) |\n|---|---|---:|---|---|---|---|\n";
        foreach ($rows as $r) {
            $md .= sprintf(
                "| %s | %s | %d | %s | %s | %s | %s |\n",
                $r['template'], $r['strategy'], $r['samples'],
                $this->fmt($r['lcp'], $r['lcpΔ'], 'ms'),
                $this->fmt($r['inp'], $r['inpΔ'], 'ms'),
                $this->fmt($r['cls'], $r['clsΔ'], '', 3),
                $this->fmt($r['perf'], $r['perfΔ'], ''),
            );
        }

        $md .= "\n## Alerts\n\n";
        $md .= empty($alerts) ? "_None._\n" : ('- '.implode("\n- ", $alerts)."\n");

        return $md;
    }
}
