<?php

namespace SsSystems\Platform\Reports;

/**
 * One PageFetcher::fetch() outcome. Every one of the ten commands wraps its
 * Http::get() in a try/catch(ConnectionException) that turns a network
 * failure into an empty/null result rather than letting it bubble — this
 * type is that same distinction, made explicit instead of overloading an
 * empty string.
 */
final class PageFetchResult
{
    /**
     * @param  array<string, array<int, string>>  $headers  Laravel's own Response::headers() shape (each header name => list of values); [] on a failed fetch
     */
    private function __construct(
        public readonly bool $successful,
        public readonly ?int $status,
        public readonly array $headers,
        public readonly string $body,
        public readonly ?float $elapsedMs,
    ) {
    }

    /**
     * A response that came back, whatever its status. `successful` mirrors
     * Laravel's own Response::successful() (2xx only) — a 404/500 fetch is
     * NOT successful even though the connection worked, exactly like every
     * command's `$resp->successful() ? $resp->body() : ''` check today.
     *
     * @param  array<string, array<int, string>>  $headers
     */
    public static function make(int $status, array $headers, string $body, ?float $elapsedMs = null): self
    {
        return new self($status >= 200 && $status < 300, $status, $headers, $body, $elapsedMs);
    }

    /** The connection itself failed — timeout, DNS, refused. Every command's catch(ConnectionException) block becomes this. */
    public static function failed(?float $elapsedMs = null): self
    {
        return new self(false, null, [], '', $elapsedMs);
    }
}
