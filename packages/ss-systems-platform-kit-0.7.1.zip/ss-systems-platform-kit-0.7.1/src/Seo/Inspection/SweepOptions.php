<?php

namespace SsSystems\Platform\Seo\Inspection;

/**
 * UrlInspectionSweep::run()'s options — mirrors seo:gsc-inspect-bulk's own
 * --flags (dashes to underscores, see fromArray()), plus one addition:
 * dry_run, which the original command does not have. SearchConsoleSync
 * already established the pattern of a dry_run option that still queries
 * the external API but skips every write; a dry URL-Inspection sweep
 * cannot follow that pattern — a real inspect() call spends real, scarce
 * quota, the entire reason Google's daily ceiling exists — so dry_run here
 * means something stricter: resolve and prioritize the URL pool, report how
 * many URLs WOULD be inspected, and call nothing else — no inspect(), no
 * quota consumption, no CoverageStore read or write. See
 * UrlInspectionSweep::run().
 */
final class SweepOptions
{
    /**
     * @param  list<string>  $include  Pools to sweep when $urls is empty: sitemap, coverage (rows the sitemap no longer carries), tracked (paths Googlebot 404s on).
     * @param  list<string>  $urls  Inspect exactly these URLs instead of the sitemap/coverage/tracked pools (a Console export, tracked 404s) — when non-empty, $limit and $strategy are ignored, exactly like the original command.
     */
    public function __construct(
        public readonly int $limit = 0,
        public readonly ?string $sitemapOverride = null,
        public readonly string $strategy = 'stale',
        public readonly array $include = ['sitemap', 'coverage', 'tracked'],
        public readonly array $urls = [],
        public readonly string $source = 'sitemap',
        public readonly ?string $reason = null,
        public readonly ?string $siteUrl = null,
        public readonly bool $dryRun = false,
    ) {
    }

    /**
     * @param  array<string, mixed>  $options  snake_case keys mirroring the artisan command's own --flag-name options (limit, sitemap, strategy, include, urls, source, reason, site, dry_run).
     */
    public static function fromArray(array $options): self
    {
        $include = $options['include'] ?? 'sitemap,coverage,tracked';
        $include = is_array($include) ? $include : explode(',', (string) $include);

        return new self(
            limit: (int) ($options['limit'] ?? 0),
            sitemapOverride: isset($options['sitemap']) && $options['sitemap'] !== '' ? (string) $options['sitemap'] : null,
            strategy: (string) ($options['strategy'] ?? 'stale'),
            include: array_values(array_filter(array_map('trim', $include), fn (string $v): bool => $v !== '')),
            urls: array_values(array_filter(array_map('trim', (array) ($options['urls'] ?? [])), fn (string $v): bool => $v !== '')),
            source: (string) ($options['source'] ?? 'sitemap'),
            reason: isset($options['reason']) && $options['reason'] !== '' ? (string) $options['reason'] : null,
            siteUrl: isset($options['site']) && $options['site'] !== '' ? (string) $options['site'] : null,
            dryRun: (bool) ($options['dry_run'] ?? false),
        );
    }
}
