<?php

namespace SsSystems\Platform\Seo\Inspection\Contracts;

/**
 * The URLs UrlInspectionSweep's sitemap pool sweeps, and the site's own base
 * URL — needed to turn a bare tracked-404 PATH into a full URL (see
 * TrackedPaths; the 'tracked' pool is paths, not URLs, and only this
 * interface knows the site's own host).
 *
 * Mirrors gs.construction's App\Support\Seo\CrawlFiles::sitemapPath() +
 * SeoGscInspectBulk::loadSitemapUrls() (simplexml over the generated
 * sitemap.xml, <loc> in document order, [] when the file is missing or
 * unparseable) and config('app.url') for the base. A site's adapter owns
 * the file/URL fetch and the XML parsing; the kit never touches a
 * filesystem.
 */
interface SitemapSource
{
    /**
     * Every <loc> in this site's sitemap, in document order — deduplication
     * is UrlInspectionSweep's own job (it merges pools with array_unique()
     * itself, same as the original command), not this method's. [] when
     * the sitemap is missing or fails to parse — never throws.
     *
     * @param  ?string  $override  A path/URL to read instead of the site's
     *   default generated sitemap (the original command's `--sitemap=`
     *   flag). Null uses the site's own default location.
     * @return list<string>
     */
    public function urls(?string $override = null): array;

    /**
     * rtrim(config('app.url'), '/') on the original command — the base a
     * bare tracked-404 path is joined onto to build a full URL for the
     * 'tracked' off-sitemap pool.
     */
    public function baseUrl(): string;
}
