<?php

namespace SsSystems\Platform\Seo\Inspection\Contracts;

/**
 * Every read and write UrlInspectionSweep makes against a site's coverage
 * state — gs.construction's gsc_coverage_states, gsc_coverage_state_history
 * and gsc_rich_result_issues tables (App\Models\GscCoverageState,
 * GscCoverageStateHistory, GscRichResultIssue). Rows travel as plain
 * arrays, never Eloquent models, so a site's adapter is the only place that
 * touches a database — the sweep's own persist()/prioritize()/
 * writeReport() logic only ever reads and writes the shapes documented on
 * each method here.
 *
 * A coverage row's keys mirror the gsc_coverage_states columns exactly
 * (see database/migrations/2026_05_29_020000_..., and
 * 2026_09_12_090000_add_source_to_gsc_coverage_states_table for `source`/
 * `console_reason`): url, source, console_reason, verdict, coverage_state,
 * robots_txt_state, indexing_state, page_fetch_state, sitemap_url,
 * last_crawl_time, user_canonical, google_canonical, inspected_at,
 * last_changed_at, consecutive_failures. Every timestamp travels as a
 * string — Carbon::now()->toIso8601String() for ones UrlInspectionSweep
 * stamps itself, or whatever raw string Google's API returned for
 * last_crawl_time — never a Carbon instance, so the adapter decides how
 * (or whether) to cast it for its own ORM.
 */
interface CoverageStore
{
    /**
     * Every known URL's coverage row, oldest inspected_at first — the whole
     * table. Feeds the 'coverage' off-sitemap pool: rows whose URL the
     * sitemap no longer carries (a Console import, or a page that has since
     * left the sitemap) still get revisited.
     *
     * Mirrors GscCoverageState::query()->orderBy('inspected_at')->pluck('url').
     *
     * @return list<string>
     */
    public function knownUrls(): array;

    /**
     * The subset of $urls that already have a coverage row, oldest
     * inspected_at first — the 'stale' prioritize() strategy's input. Those
     * URLs are placed BEHIND never-seen URLs in the run order (see
     * UrlInspectionSweep::prioritize()), oldest-inspected of them first, so
     * the run always revisits what has gone longest without a look.
     *
     * Mirrors GscCoverageState::query()->whereIn('url',
     * $urls)->orderBy('inspected_at')->pluck('url')->all().
     *
     * @param  list<string>  $urls
     * @return list<string>
     */
    public function knownUrlsAmong(array $urls): array;

    /**
     * The existing row for one URL, or null when it has never been
     * inspected. UrlInspectionSweep::persist() reads `source`, `verdict`,
     * `coverage_state`, `page_fetch_state`, `google_canonical`,
     * `console_reason`, `last_changed_at` and `consecutive_failures` off
     * this to decide whether the state changed and to carry forward what a
     * fresh inspection doesn't overwrite (the original source, an unset
     * console_reason).
     *
     * @return array{
     *     url: string,
     *     source: ?string,
     *     console_reason: ?string,
     *     verdict: ?string,
     *     coverage_state: ?string,
     *     robots_txt_state: ?string,
     *     indexing_state: ?string,
     *     page_fetch_state: ?string,
     *     sitemap_url: ?string,
     *     last_crawl_time: ?string,
     *     user_canonical: ?string,
     *     google_canonical: ?string,
     *     inspected_at: ?string,
     *     last_changed_at: ?string,
     *     consecutive_failures: int,
     * }|null
     */
    public function find(string $url): ?array;

    /**
     * Insert or update the one row keyed on `url` — GscCoverageState::
     * updateOrCreate(['url' => ...], [...]) with exactly this row's other
     * keys as the update payload.
     *
     * @param  array{
     *     url: string,
     *     source: string,
     *     console_reason: ?string,
     *     verdict: ?string,
     *     coverage_state: ?string,
     *     robots_txt_state: ?string,
     *     indexing_state: ?string,
     *     page_fetch_state: ?string,
     *     sitemap_url: ?string,
     *     last_crawl_time: ?string,
     *     user_canonical: ?string,
     *     google_canonical: ?string,
     *     inspected_at: string,
     *     last_changed_at: string,
     *     consecutive_failures: int,
     * }  $row
     */
    public function upsert(array $row): void;

    /**
     * Append one history row — called only when persist() decided the state
     * changed. Mirrors GscCoverageStateHistory::create([...]).
     *
     * @param  array{
     *     url: string,
     *     verdict: ?string,
     *     coverage_state: ?string,
     *     page_fetch_state: ?string,
     *     observed_at: string,
     * }  $row
     */
    public function recordHistory(array $row): void;

    /**
     * Replace every rich-result issue row for one URL: delete what is
     * stored, then insert $issues (which may be [] — a URL that used to
     * have issues and now has none must end up with zero rows, exactly like
     * the original's GscRichResultIssue::query()->where('url',
     * $url)->delete() running UNCONDITIONALLY before persistRichResults()
     * decides whether anything gets re-inserted).
     *
     * @param  list<array{
     *     rich_result_type: string,
     *     issue_severity: string,
     *     issue_type: string,
     *     issue_message: string,
     *     verdict: ?string,
     *     inspected_at: string,
     * }>  $issues
     */
    public function replaceRichResultIssues(string $url, array $issues): void;

    /**
     * (verdict, coverage_state) => row count across the WHOLE table, most
     * common first — the "Current coverage snapshot" table writeReport()
     * prints. Mirrors GscCoverageState::query()->selectRaw('verdict,
     * coverage_state, count(*) as n')->groupBy('verdict',
     * 'coverage_state')->orderByDesc('n')->get().
     *
     * @return list<array{verdict: ?string, coverage_state: ?string, n: int}>
     */
    public function verdictCoverageTotals(): array;
}
