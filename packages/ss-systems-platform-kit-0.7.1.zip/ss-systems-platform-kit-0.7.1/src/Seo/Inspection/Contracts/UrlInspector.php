<?php

namespace SsSystems\Platform\Seo\Inspection\Contracts;

/**
 * One call to Google's URL Inspection API (urlInspection/index:inspect),
 * against whichever property this site inspects. Mirrors gs.construction's
 * App\Services\GoogleSearchConsoleService::inspectUrl() exactly — that
 * method already has this shape (inspectionResult-or-null, lastError()) —
 * so a site typically implements this interface directly on its existing
 * Search Console service rather than writing a new adapter class.
 *
 * inspect() must never throw for a network failure, same rule as this
 * kit's Reports\Contracts\PageFetcher: the implementation catches its own
 * connection exceptions and returns null with lastError() describing what
 * happened, exactly like every self-crawl report's
 * try/catch(ConnectionException) already does elsewhere in this kit.
 * UrlInspectionSweep does not wrap calls to inspect() in a try/catch.
 */
interface UrlInspector
{
    /**
     * @return array<string, mixed>|null  Google's raw `inspectionResult`
     *   object (indexStatusResult, richResultsResult, mobileUsabilityResult,
     *   …) exactly as the API hands it back, or null on ANY failure — call
     *   lastError() for what went wrong.
     */
    public function inspect(string $siteUrl, string $url): ?array;

    /**
     * The failure behind the most recent inspect() call that returned null.
     * Null after a successful call, or before the first call.
     *
     * @return array{status: ?int, message: string}|null  `status` is the
     *   HTTP status Google answered with (429 means the property's quota is
     *   spent — UrlInspectionSweep stops the run on it), or null when the
     *   call never reached Google at all (timeout, DNS, connection
     *   refused) — the same distinction PageFetchResult::failed() makes
     *   with a null `status`.
     */
    public function lastError(): ?array;

    /**
     * The property this inspector inspects against — e.g.
     * 'sc-domain:gs.construction' or a full URL prefix. Resolved without a
     * live API call, so a sweep can log it even when every inspection in
     * the run fails.
     */
    public function siteUrl(): string;

    /**
     * Whether a call to inspect() could reach Google at all right now: the
     * site holds a Search Console grant. UrlInspectionSweep asks this ONCE
     * before it touches the quota, because gs.construction's original
     * command exited before spending anything when no token was stored,
     * and a sweep that consumed one allowance unit per URL only to fail
     * each call with "No access token" would burn a day's quota on nothing.
     */
    public function isReady(): bool;
}
