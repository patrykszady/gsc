<?php

namespace SsSystems\Platform\Seo\Inspection;

use Illuminate\Support\Carbon;
use SsSystems\Platform\Seo\Inspection\Contracts\CoverageStore;
use SsSystems\Platform\Seo\Inspection\Contracts\SitemapSource;
use SsSystems\Platform\Seo\Inspection\Contracts\TrackedPaths;
use SsSystems\Platform\Seo\Inspection\Contracts\UrlInspector;

/**
 * The nightly URL-Inspection sweep — ported verbatim from gs.construction's
 * app/Console/Commands/SeoGscInspectBulk.php (handle(), offSitemapUrls(),
 * prioritize(), persist(), persistRichResults(), writeReport(); the
 * original's loadSitemapUrls() — reading and simplexml-parsing a
 * sitemap.xml file — is filesystem I/O and lives in the site's
 * SitemapSource adapter instead, but the ORDER it produces — document
 * order, sitemap pool first, off-sitemap extras appended, then
 * deduplicated — is preserved exactly here).
 *
 * Walks pools of URLs (the sitemap, coverage rows the sitemap no longer
 * carries, tracked 404 paths) under a daily/per-minute quota
 * (UrlInspectionQuota), calls Google's URL Inspection API for each through
 * an injected UrlInspector, persists every verdict through CoverageStore
 * (+ a history row on change, + rich-result issues), and returns a
 * markdown summary. See docs/INSPECTION-SWEEP.md for how a site wires this
 * up, and SweepOptions/SweepResult for the exact shapes in and out.
 *
 * One behaviour intentionally NOT ported: the original command refreshes
 * its Search Console access token mid-sweep on a 401 (a long sweep can
 * outlive the one token it fetched at the start of handle()). UrlInspector
 * abstracts a site's whole inspection call, and gs.construction's own
 * App\Services\GoogleSearchConsoleService::inspectUrl() (the intended
 * implementation) already fetches a fresh-or-cached token on EVERY call
 * rather than reusing one token for the whole run — so the 401-mid-sweep
 * problem that logic was working around does not exist behind that
 * interface. A UrlInspector implementation that DOES reuse one long-lived
 * token is responsible for refreshing it itself; this class only ever
 * sees inspect() return null + lastError().
 */
final class UrlInspectionSweep
{
    /** @var callable(int): void */
    private $sleeper;

    /**
     * @param  ?callable(int): void  $sleeper  Called with the pacing gap in
     *   microseconds between inspections — usleep() by default. Inject a
     *   no-op in tests so a sweep over many URLs runs instantly.
     */
    public function __construct(
        private readonly UrlInspector $inspector,
        private readonly SitemapSource $sitemapSource,
        private readonly CoverageStore $store,
        private readonly TrackedPaths $trackedPaths,
        private readonly UrlInspectionQuota $quota,
        ?callable $sleeper = null,
    ) {
        $this->sleeper = $sleeper ?? static function (int $microseconds): void {
            usleep($microseconds);
        };
    }

    /** The line a run ends with when the site holds no Search Console grant; a site's command exits 1 on it. */
    public const NOT_CONNECTED_LINE = 'Search Console is not connected on this site; nothing was inspected.';

    public function run(SweepOptions|array $options): SweepResult
    {
        $opts = is_array($options) ? SweepOptions::fromArray($options) : $options;
        $lines = [];

        $siteUrl = $opts->siteUrl ?? $this->inspector->siteUrl();

        // Asked before the pools are even loaded and before a single quota
        // unit is reserved: without a grant every inspect() would fail
        // after consuming its allowance. A site's thin command treats this
        // line as its failure exit, like "Nothing to inspect.".
        if (! $this->inspector->isReady()) {
            $lines[] = self::NOT_CONNECTED_LINE;

            return new SweepResult(0, 0, [], 0, false, $this->quota->remaining(), '', $lines);
        }

        if ($opts->urls !== []) {
            $urls = $opts->urls;
        } else {
            $sitemapUrls = $this->sitemapSource->urls($opts->sitemapOverride);
            $urls = in_array('sitemap', $opts->include, true) ? $sitemapUrls : [];
            $offSitemap = $this->offSitemapUrls($opts->include, $sitemapUrls);
            $urls = array_values(array_unique(array_merge($urls, $offSitemap)));

            $lines[] = $offSitemap !== []
                ? sprintf('Loaded %d sitemap URL(s) + %d that the sitemap does not carry.', count($sitemapUrls), count($offSitemap))
                : sprintf('Loaded %d sitemap URLs.', count($sitemapUrls));
        }

        if ($urls === []) {
            $lines[] = 'Nothing to inspect.';

            return new SweepResult(0, 0, [], 0, false, $this->quota->remaining(), '', $lines);
        }

        $limit = $opts->limit > 0 ? $opts->limit : count($urls);
        $urls = $opts->urls !== [] ? $urls : $this->prioritize($urls, $opts->strategy, $limit);

        if ($opts->dryRun) {
            // Touches nothing: no inspect() call, no quota consumption, no
            // CoverageStore read or write — see SweepOptions's docblock for
            // why this is stricter than SearchConsoleSync's dry_run.
            $lines[] = sprintf('Dry run: would inspect %d URL(s) (strategy=%s). Nothing was called or written.', count($urls), $opts->strategy);

            return new SweepResult(0, 0, [], 0, false, $this->quota->remaining(), '', $lines);
        }

        // The allowance is the property's, not this run's: an import or an
        // admin inspection earlier today has already spent part of it.
        $allowed = $this->quota->reserve(count($urls));
        if ($allowed <= 0) {
            $lines[] = sprintf(
                'The URL Inspection allowance for today is spent (%d/%d). It resets %s.',
                $this->quota->used(), $this->quota->dailyLimit(), $this->quota->resetsAt()->diffForHumans()
            );

            return new SweepResult(0, 0, [], 0, false, $this->quota->remaining(), '', $lines);
        }
        if ($allowed < count($urls)) {
            $lines[] = sprintf('Only %d of %d URLs fit in today\'s remaining allowance; the rest go on the next run.', $allowed, count($urls));
            $urls = array_slice($urls, 0, $allowed);
        }

        $lines[] = sprintf('Inspecting %d URLs (strategy=%s, %d left in today\'s allowance).', count($urls), $opts->strategy, $this->quota->remaining());

        $changes = [];
        $failures = 0;
        $inspected = 0;
        $richIssues = 0;
        $stoppedOnQuota = false;

        // 600 calls a minute is the other ceiling; 250ms apart is 240/min.
        $pacing = max(100_000, (int) ceil(60_000_000 / $this->quota->perMinuteLimit()) * 2);

        foreach ($urls as $u) {
            ($this->sleeper)($pacing);
            $this->quota->consume();

            $result = $this->inspector->inspect($siteUrl, $u);

            if ($result === null) {
                $failures++;
                $error = $this->inspector->lastError();
                $status = $error['status'] ?? null;

                if ($status === null) {
                    $lines[] = sprintf('  err   net  %s (%s)', $u, $error['message'] ?? 'unknown error');

                    continue;
                }

                $lines[] = sprintf('  err   %3d  %s', $status, $u);

                if ($status === 429) {
                    // Google is the authority on the allowance, whatever our
                    // own count says — another client shares this property.
                    $this->quota->markExhausted();
                    $lines[] = 'Google refused on quota; stopping early. It resets '.$this->quota->resetsAt()->diffForHumans().'.';
                    $stoppedOnQuota = true;

                    break;
                }

                continue;
            }

            $inspected++;
            $r = $result['indexStatusResult'] ?? [];
            $change = $this->persist($u, $r, $result['richResultsResult'] ?? [], $opts);
            if (($change['changed'] ?? false) === true) {
                $changes[] = $change;
            }
            $richIssues += (int) ($change['rich_issue_count'] ?? 0);

            $verdict = $r['verdict'] ?? '?';
            $coverage = $r['coverageState'] ?? '?';
            $lines[] = sprintf('  %-7s %-45s %s', $verdict, substr((string) $coverage, 0, 45), $u);
        }

        $lines[] = sprintf(
            'Done. inspected=%d failures=%d changes=%d rich_issues=%d allowance_left=%d',
            $inspected, $failures, count($changes), $richIssues, $this->quota->remaining()
        );

        $markdown = $this->writeReport($inspected, $failures, $changes);

        return new SweepResult($inspected, $failures, $changes, $richIssues, $stoppedOnQuota, $this->quota->remaining(), $markdown, $lines);
    }

    /**
     * The URLs Search Console counts that our sitemap does not carry.
     *
     * 'coverage' keeps refreshing rows whose URL has left the sitemap or
     * arrived from a Console export — without this the sweep can never
     * revisit them, so a fix there would never show. 'tracked' adds the
     * paths Googlebot actually 404s on, which is the only way those appear
     * in our own copy of the report at all.
     *
     * @param  list<string>  $pools
     * @param  list<string>  $sitemapUrls
     * @return list<string>
     */
    private function offSitemapUrls(array $pools, array $sitemapUrls): array
    {
        $known = array_flip($sitemapUrls);
        $extra = [];

        if (in_array('coverage', $pools, true)) {
            foreach ($this->store->knownUrls() as $url) {
                if (! isset($known[$url])) {
                    $extra[$url] = true;
                }
            }
        }

        if (in_array('tracked', $pools, true)) {
            $base = rtrim($this->sitemapSource->baseUrl(), '/');
            foreach ($this->trackedPaths->recent404Paths() as $path) {
                $url = $base.'/'.ltrim($path, '/');
                if (! isset($known[$url])) {
                    $extra[$url] = true;
                }
            }
        }

        return array_keys($extra);
    }

    /**
     * Pick URLs that need inspection most: oldest inspected_at first
     * (stale), else random sample, else all in declared order — capped at
     * the limit.
     *
     * @param  list<string>  $urls
     * @return list<string>
     */
    private function prioritize(array $urls, string $strategy, int $limit): array
    {
        if ($strategy === 'random') {
            shuffle($urls);

            return array_slice($urls, 0, $limit);
        }
        if ($strategy === 'all') {
            return array_slice($urls, 0, $limit);
        }

        // stale: known rows ordered by inspected_at ASC, then never-inspected URLs to fill.
        $known = $this->store->knownUrlsAmong($urls);
        $unseen = array_values(array_diff($urls, $known));
        $merged = array_merge($unseen, $known); // never-seen first, then oldest stale

        return array_slice($merged, 0, $limit);
    }

    /**
     * Persist + return a change description; 'changed' is true only when
     * verdict/coverage/page_fetch_state/canonical shifted since the
     * previous inspection.
     *
     * @param  array<string, mixed>  $r
     * @param  array<string, mixed>  $richResults
     * @return array{url: string, prev_verdict: ?string, verdict: ?string, prev_coverage: ?string, coverage: ?string, rich_issue_count: int, changed: bool}
     */
    private function persist(string $url, array $r, array $richResults, SweepOptions $opts): array
    {
        $verdict = $r['verdict'] ?? null;
        $coverage = $r['coverageState'] ?? null;
        $pageFetch = $r['pageFetchState'] ?? null;
        $userCanon = $r['userCanonical'] ?? null;
        $googleCanon = $r['googleCanonical'] ?? null;

        $existing = $this->store->find($url);
        $changed = $existing === null
            || ($existing['verdict'] ?? null) !== $verdict
            || ($existing['coverage_state'] ?? null) !== $coverage
            || ($existing['page_fetch_state'] ?? null) !== $pageFetch
            || ($existing['google_canonical'] ?? null) !== $googleCanon;

        $now = Carbon::now()->toIso8601String();

        $this->store->upsert([
            'url' => $url,
            // A sitemap sweep never demotes a row imported from the
            // Console: it keeps the source that first explained it.
            'source' => ($existing['source'] ?? null) && $existing['source'] !== 'sitemap' ? $existing['source'] : ($opts->source ?: 'sitemap'),
            'console_reason' => $opts->reason ?? ($existing['console_reason'] ?? null),
            'verdict' => $verdict,
            'coverage_state' => $coverage,
            'robots_txt_state' => $r['robotsTxtState'] ?? null,
            'indexing_state' => $r['indexingState'] ?? null,
            'page_fetch_state' => $pageFetch,
            'sitemap_url' => $r['sitemap'][0] ?? null,
            'last_crawl_time' => $r['lastCrawlTime'] ?? null,
            'user_canonical' => $userCanon,
            'google_canonical' => $googleCanon,
            'inspected_at' => $now,
            'last_changed_at' => $changed ? $now : (($existing['last_changed_at'] ?? null) ?? $now),
            'consecutive_failures' => $verdict !== 'PASS'
                ? ((int) ($existing['consecutive_failures'] ?? 0) + 1)
                : 0,
        ]);

        $richIssueCount = $this->persistRichResults($url, $richResults);

        $description = [
            'url' => $url,
            'prev_verdict' => $existing['verdict'] ?? null,
            'verdict' => $verdict,
            'prev_coverage' => $existing['coverage_state'] ?? null,
            'coverage' => $coverage,
            'rich_issue_count' => $richIssueCount,
            'changed' => $changed,
        ];

        if ($changed) {
            $this->store->recordHistory([
                'url' => $url,
                'verdict' => $verdict,
                'coverage_state' => $coverage,
                'page_fetch_state' => $pageFetch,
                'observed_at' => $now,
            ]);
        }

        return $description;
    }

    /**
     * Replace current rich-result issues for a URL from the URL Inspection
     * response.
     *
     * @param  array<string, mixed>  $richResults
     */
    private function persistRichResults(string $url, array $richResults): int
    {
        $rows = [];
        $items = $richResults['detectedItems'] ?? [];

        if (is_array($items) && $items !== []) {
            $verdict = is_string($richResults['verdict'] ?? null) ? (string) $richResults['verdict'] : null;
            $inspectedAt = Carbon::now()->toIso8601String();

            foreach ($items as $item) {
                if (! is_array($item)) {
                    continue;
                }

                $type = (string) ($item['richResultType'] ?? $item['detectedItemType'] ?? 'Unknown');
                $issues = $item['issues'] ?? [];
                if (! is_array($issues) || $issues === []) {
                    continue;
                }

                foreach ($issues as $issue) {
                    if (! is_array($issue)) {
                        continue;
                    }

                    $rows[] = [
                        'rich_result_type' => $type,
                        'issue_severity' => (string) ($issue['severity'] ?? 'UNKNOWN'),
                        'issue_type' => (string) ($issue['issueType'] ?? $issue['issueMessage'] ?? 'unknown_issue'),
                        'issue_message' => (string) ($issue['issueMessage'] ?? $issue['issueType'] ?? 'Unknown issue'),
                        'verdict' => $verdict,
                        'inspected_at' => $inspectedAt,
                    ];
                }
            }
        }

        // Unconditional: a URL that used to have issues and now has none
        // must end up with zero stored rows.
        $this->store->replaceRichResultIssues($url, $rows);

        return count($rows);
    }

    /**
     * @param  list<array{url: string, prev_verdict: ?string, verdict: ?string, prev_coverage: ?string, coverage: ?string, rich_issue_count: int, changed: bool}>  $changes
     */
    private function writeReport(int $inspected, int $failures, array $changes): string
    {
        $lines = [];
        $lines[] = '# GSC URL Inspection — bulk run';
        $lines[] = '';
        $lines[] = '_Generated: '.Carbon::now()->toIso8601String().'_';
        $lines[] = '';
        $lines[] = "- Inspected: **{$inspected}**";
        $lines[] = "- API failures: **{$failures}**";
        $lines[] = '- State changes: **'.count($changes).'**';
        $lines[] = '';

        $lines[] = '## Current coverage snapshot';
        $lines[] = '';
        $lines[] = '| Verdict | Coverage state | Count |';
        $lines[] = '|---|---|---|';
        foreach ($this->store->verdictCoverageTotals() as $t) {
            $lines[] = sprintf('| %s | %s | %d |', $t['verdict'] ?? '?', $t['coverage_state'] ?? '?', $t['n']);
        }
        $lines[] = '';

        if ($changes) {
            $lines[] = '## State changes this run';
            $lines[] = '';
            $lines[] = '| URL | Verdict (prev → now) | Coverage (prev → now) |';
            $lines[] = '|---|---|---|';
            foreach ($changes as $c) {
                $lines[] = sprintf(
                    '| %s | %s → %s | %s → %s |',
                    $c['url'],
                    $c['prev_verdict'] ?? '–',
                    $c['verdict'] ?? '–',
                    $c['prev_coverage'] ?? '–',
                    $c['coverage'] ?? '–',
                );
            }
            $lines[] = '';
        }

        return implode("\n", $lines);
    }
}
