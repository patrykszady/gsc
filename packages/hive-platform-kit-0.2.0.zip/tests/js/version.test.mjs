import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');

// The sites install this package from a zip archive, and Composer reads an
// artifact's version from its composer.json — so that field must exist, and
// it must say what Kit::VERSION (the drift trip-wire in every /ping) says.
test('composer.json and Kit::VERSION name the same release', () => {
  const composer = JSON.parse(fs.readFileSync(path.join(root, 'composer.json'), 'utf8'));
  const kit = fs.readFileSync(path.join(root, 'src/Kit.php'), 'utf8').match(/VERSION = '([^']+)'/)[1];

  assert.equal(composer.version, kit);
});
