import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { businessNameFrom, decodeEntities, parseAngiPage, reviewPropsFrom, structuredReviewsFrom } from '../../resources/scripts/lib/angi-page.mjs';
import { parseProxyUrl, sessionUsername } from '../../resources/scripts/lib/residential-proxy.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const fixture = (name) => fs.readFileSync(path.join(here, 'fixtures', name), 'utf8');

// Cut from the live pages on 2026-09-21: the H1 and the one flight chunk that
// carries the reviews component's props, nothing else.
const jpeterson = fixture('angi-profile-jpeterson.html');
const gsc = fixture('angi-profile-gsc.html');

test('reads every review out of the Next.js flight payload', () => {
  const page = parseAngiPage(jpeterson);

  assert.equal(page.businessName, 'J. PETERSON DESIGN');
  assert.equal(page.reviewCount, 7);
  assert.equal(page.currentPage, 1);
  assert.equal(page.totalPages, 1);
  assert.equal(page.reviews.length, 7);

  const first = page.reviews[0];
  assert.equal(first.reviewer_name, 'Bonnie R.');
  assert.equal(first.star_rating, 5);
  assert.equal(first.review_date_raw, 'January 2015');
  assert.match(first.review_description, /^Jen is the greatest\./);
  assert.ok(first.review_description.endsWith('I am in love with my new kitchen.'), 'the body is the full text, not a card excerpt');
});

test("Angi's 'unknown' placeholder is no review body", () => {
  const page = parseAngiPage(jpeterson);
  const donK = page.reviews.find((r) => r.reviewer_name === 'don K.');

  assert.ok(donK, 'the rating-only review is still listed');
  assert.equal(donK.review_description, '', 'so the importer skips it rather than storing "unknown"');
  assert.equal(donK.star_rating, 5);
});

test('the business name is the H1, entities decoded', () => {
  assert.equal(businessNameFrom(gsc), 'GS Construction & Remodeling');
  assert.equal(parseAngiPage(gsc).businessName, 'GS Construction & Remodeling');
  assert.equal(parseAngiPage(gsc).reviews.length, 3);
});

test('a page without the reviews component reads as no data — a block page, or one past the last', () => {
  assert.equal(parseAngiPage('<html><head><title>Attention Required! | Cloudflare</title></head><body><h1>Sorry, you have been blocked</h1></body></html>'), null);
  assert.equal(reviewPropsFrom('<script>self.__next_f.push([1,"3:{\\"reviews\\":\\"not a list\\"}"])</script>'), null);
});

test('the old LocalBusiness block is still understood, with no page count', () => {
  const html = `<html><body><h1>Old Page</h1><script type="application/ld+json">${JSON.stringify({
    '@type': 'LocalBusiness',
    name: 'GS Construction &amp; Remodeling',
    aggregateRating: { reviewCount: 2 },
    review: [{ author: { name: 'Teresa M.' }, reviewBody: 'Great remodel, couldn&amp;#39;t be happier.', datePublished: '2022-12-21', reviewRating: { ratingValue: 5 } }],
  })}</script></body></html>`;

  const page = parseAngiPage(html);
  assert.equal(page.businessName, 'GS Construction & Remodeling');
  assert.equal(page.totalPages, null, 'unknown, so the walker keeps going until a page adds nothing');
  assert.equal(page.reviews[0].review_description, "Great remodel, couldn't be happier.");
  assert.equal(structuredReviewsFrom(jpeterson), null, 'the new page has no such block');
});

test('entities decode until they settle', () => {
  assert.equal(decodeEntities('couldn&amp;#39;t &amp;amp; wouldn&#x27;t'), "couldn't & wouldn't");
  assert.equal(decodeEntities('&bogus; stays'), '&bogus; stays');
});

test('a proxy session pins a US exit unless the username already names a region', () => {
  assert.equal(sessionUsername('u123-zone-custom', 'us', 'ab12'), 'u123-zone-custom-region-us-session-ab12');
  assert.equal(sessionUsername('u123-zone-custom', 'US', 'ab12'), 'u123-zone-custom-region-us-session-ab12');
  assert.equal(sessionUsername('u123-zone-custom-region-ca', 'us', 'ab12'), 'u123-zone-custom-region-ca-session-ab12', 'an operator\'s own region wins');
  assert.equal(sessionUsername('u123-zone-custom', '', 'ab12'), 'u123-zone-custom-session-ab12', 'no region when none is asked for');
});

test('a proxy URL splits into what Chromium and the page each need', () => {
  assert.deepEqual(parseProxyUrl('http://user:p%40ss@na.proxy.example.com:2334'), {
    host: 'http://na.proxy.example.com:2334',
    username: 'user',
    password: 'p@ss',
  });
  assert.equal(parseProxyUrl('not a url'), null);
  assert.equal(parseProxyUrl(''), null);
});
