<?php

namespace Hive\Platform\Reviews;

use Illuminate\Support\Carbon;

/**
 * The text rules a review import needs: what counts as the same review on
 * two sites, what a scraped card becomes before it is stored, and how a
 * business name compares with a page heading.
 *
 * Pure functions, shared by every site's importers so that "same review"
 * means one thing everywhere.
 */
final class ReviewText
{
    /**
     * HTML entities decoded, in case a stored review kept them: "couldn&#39;t"
     * and "couldn't" are the same review and must compare equal. Angi
     * double-encodes, so decode until it settles.
     */
    public static function decodeEntities(string $value): string
    {
        for ($pass = 0; $pass < 3; $pass++) {
            $decoded = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if ($decoded === $value) {
                break;
            }
            $value = $decoded;
        }

        return $value;
    }

    /** Letters, digits and single spaces only — punctuation and encoding differ between sites. */
    public static function comparable(?string $text, int $length = 160): string
    {
        $text = self::decodeEntities((string) $text);
        $text = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text) ?: $text;
        $text = (string) preg_replace('/[^a-zA-Z0-9 ]/', '', $text);
        $text = mb_strtolower((string) preg_replace('/\s+/', ' ', trim($text)));

        return mb_substr($text, 0, $length);
    }

    /** Letters and digits only, for comparing a business name with a URL slug or page heading. */
    public static function normalizeName(string $value): string
    {
        return (string) preg_replace('/[^a-z0-9]+/', '', mb_strtolower($value));
    }

    /**
     * A scraped Angi review as the site stores it, or null when it is not a
     * review at all.
     *
     * Angi lets a customer leave a rating without a write-up and publishes
     * the body as the word "unknown". That is a rating, not a review, and it
     * is dropped here as well as in the scraper — a payload captured by an
     * older scraper could still carry it.
     *
     * The date is whatever Angi gives: an ISO timestamp on the old page, a
     * month ("January 2015") on the new one, which lands on the first.
     *
     * @param  array<string, mixed>  $review
     * @return array{reviewer_name: string, review_description: string, review_date: ?Carbon, star_rating: ?int}|null
     */
    public static function normalizeAngiReview(array $review): ?array
    {
        $name = trim(self::decodeEntities((string) ($review['reviewer_name'] ?? '')));
        $description = trim(self::decodeEntities((string) ($review['review_description'] ?? '')));
        if (strcasecmp($description, 'unknown') === 0) {
            $description = '';
        }
        if ($name === '' || $description === '') {
            return null;
        }

        $date = null;
        $rawDate = trim((string) ($review['review_date_raw'] ?? ''));
        if ($rawDate !== '') {
            try {
                $date = Carbon::parse($rawDate)->startOfDay();
            } catch (\Throwable) {
                $date = null;
            }
        }

        $rating = isset($review['star_rating']) ? (int) $review['star_rating'] : null;
        if ($rating !== null && ($rating < 1 || $rating > 5)) {
            $rating = null;
        }

        return [
            'reviewer_name' => $name,
            'review_description' => $description,
            'review_date' => $date,
            'star_rating' => $rating,
        ];
    }

    /**
     * One key per distinct review within a scrape.
     *
     * @param  array{reviewer_name: string, review_description: string, review_date: ?Carbon}  $payload
     */
    public static function payloadKey(array $payload): string
    {
        return mb_strtolower(trim($payload['reviewer_name']))
            .'|'.($payload['review_date']?->toDateString() ?? 'no-date')
            .'|'.self::comparable($payload['review_description']);
    }
}
