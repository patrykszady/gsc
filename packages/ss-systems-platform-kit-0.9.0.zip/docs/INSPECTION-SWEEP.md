# Wiring the URL-Inspection sweep into a site

`SsSystems\Platform\Seo\Inspection\UrlInspectionSweep` is the kit's port of
gs.construction's `seo:gsc-inspect-bulk` (see the class's own docblock for
what was, and wasn't, ported verbatim). A site wires it the same way it
wires `SsSystems\Platform\Seo\SearchConsoleSync`: the kit owns the
algorithm, the site owns four small adapters, a `UrlInspectionQuota`
instance, and a thin artisan command.

## 1. Implement the four interfaces

| Interface | Wraps |
|---|---|
| `Contracts\UrlInspector` | The site's own Search Console service's URL Inspection call — gs.construction's `App\Services\GoogleSearchConsoleService` already has this exact shape (`inspectUrl()` ≈ `inspect()`, `getLastError()` ≈ `lastError()`); add `siteUrl(): string` (gsc: `SearchConsoleProperty::url()`). |
| `Contracts\SitemapSource` | `urls()` reads and parses the generated `sitemap.xml` (gsc: `App\Support\Seo\CrawlFiles::sitemapPath()` + simplexml, `<loc>` in document order, `[]` on a missing/bad file); `baseUrl()` is `rtrim(config('app.url'), '/')`. |
| `Contracts\CoverageStore` | Thin wrappers around `GscCoverageState`, `GscCoverageStateHistory` and `GscRichResultIssue` — every method's exact array shape is documented on the interface itself. |
| `Contracts\TrackedPaths` | `recent404Paths()` wraps `Tracked404::query()->where('user_agent', 'like', '%Googlebot%')->orderByDesc('hit_count')->pluck('path')`. A site with no 404-tracking table returns `[]`. |

Bind all four in `AppServiceProvider`, and build a `UrlInspectionQuota`
there too — one per site, its cache-key prefix already scoped to that site
(gsc: `Tenancy::cacheKey('gsc.url-inspection')`), its daily/per-minute
limits from that site's own
`services.google.search_console.inspection_{daily,per_minute}_quota`
config:

```php
$this->app->singleton(UrlInspectionQuota::class, fn () => new UrlInspectionQuota(
    cache: app(CacheInterface::class), // a PSR-16 adapter over Laravel's cache store
    keyPrefix: Tenancy::cacheKey('gsc.url-inspection'),
    dailyLimitValue: (int) config('services.google.search_console.inspection_daily_quota', 2000),
    perMinuteLimitValue: (int) config('services.google.search_console.inspection_per_minute_quota', 600),
));
```

## 2. The thin artisan command

```php
class SeoGscInspectBulk extends Command
{
    protected $signature = 'seo:gsc-inspect-bulk
        {--limit=0} {--sitemap=} {--strategy=stale}
        {--include=sitemap,coverage,tracked} {--urls=*}
        {--source=sitemap} {--reason=} {--site=} {--markdown}';

    public function handle(UrlInspectionSweep $sweep): int
    {
        $result = $sweep->run([
            'limit' => (int) $this->option('limit'),
            'sitemap' => $this->option('sitemap'),
            'strategy' => $this->option('strategy'),
            'include' => $this->option('include'),
            'urls' => $this->option('urls'),
            'source' => $this->option('source'),
            'reason' => $this->option('reason'),
            'site' => $this->option('site'),
        ]);

        foreach ($result->lines as $line) {
            $this->line($line);
        }

        if ($this->option('markdown')) {
            Storage::disk('local')->put('reports/gsc-inspect-bulk.md', $result->markdown);
            $this->info('Wrote reports/gsc-inspect-bulk.md');
        }

        // The original command's only FAILURE exit is an empty pool; a
        // spent allowance and a mid-run 429 both exit SUCCESS, same as it
        // did. SweepResult carries no status field (see its own docblock),
        // so the wrapper reads `lines` for this one case.
        if ($result->lines === ['Loaded 0 sitemap URLs.', 'Nothing to inspect.']
            || $result->lines === ['Nothing to inspect.']) {
            return self::FAILURE;
        }

        return self::SUCCESS;
    }
}
```

## 3. Schedule

Nightly, same cadence gs.construction already runs it at:

```php
$schedule->command('seo:gsc-inspect-bulk --markdown')->dailyAt('03:00');
```

jpeterson-design already has the `gsc_coverage_states` table (the migration
shipped estate-wide) but never ran this sweep, so its "Pages Google Is
Having Trouble With" card reads zero — wiring these four adapters is the
whole fix, no schema change needed.
