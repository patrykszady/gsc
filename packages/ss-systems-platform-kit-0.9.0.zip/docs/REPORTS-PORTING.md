# Porting a gsc SEO report into the shared library

This is the guide for the agents porting the remaining nine reports. Read
it before touching any file under `src/Reports/` — the interfaces and fakes
are frozen for you; if one of them genuinely doesn't cover what your report
needs, see **"If an interface doesn't cover your report"** at the bottom
instead of editing it.

`ContentDecayReport` (`src/Reports/ContentDecayReport.php`, ported from
gsc's `SeoContentDecay`) is the reference port. Read it alongside its test
(`tests/Unit/Reports/ContentDecayReportTest.php`) before starting — every
step below is exactly what that class and test already do.

## The shape

```
gsc's app/Console/Commands/Seo*.php     ──ported──▶  kit's src/Reports/*Report.php
  reads Eloquent / DB / Http / Cache /                reads only Contracts/* interfaces,
  Storage / config() directly                         injected through the constructor

site's thin app/Console/Commands/Seo*.php  ◀──wraps──  kit's Reports\*Report
  resolves the Report from the container,
  builds $options from its own --flags,
  writes ->markdown to storage, prints ->summary,
  exits non-zero on STATUS_ERROR

site's App\Support\Seo\*Adapter classes  ──implement──▶  kit's Contracts/*Reader interfaces
  wrap that site's real Eloquent models / Http calls
```

The kit owns the **algorithm** (thresholds, markdown wording, row
ordering, scoring formulas) — verbatim, transcribed from the gsc command,
never re-derived. The site owns the **adapter** (how to actually get the
data) and the **wrapper** (turning a `ReportResult` back into the artisan
command's console output and side effects).

## Steps

1. **Read the original command in full**, `gsc/app/Console/Commands/Seo*.php`.
   Note every external read: Eloquent query, `Http::get()`, `Cache::`,
   `Storage::`, `config()`, `Schema::hasTable()`. Every one of these must
   route through one of the nine `Contracts/` interfaces below — if you
   find one that doesn't fit any of them, see the last section.

2. **Create `src/Reports/<Name>Report.php` implementing `Report`.**
   `key()` returns the exact registry key from `ReportRegistry::REPORTS`
   (already listed there, pointing at your not-yet-existing class — that
   reference is intentional, see `ReportRegistry`'s own docblock). Inject
   only the interfaces your report actually needs, matching
   `ReportRegistry::get($key)['requires']`.

3. **Map every data access to an interface method.** Keep the original
   command's OWN transformation logic (clustering, scoring, classification,
   markdown building) inside your report class, verbatim — the interfaces
   only replace WHERE the raw rows come from, never HOW they're turned into
   a result. `SeoGbpParity::buildCatalog()`, `SeoCwvTemplate::classify()`,
   `SeoAreaPagesAudit::shingleSet()`/`jaccard()` etc. are exactly this kind
   of pure transformation — copy them into the report unchanged.

4. **Keep thresholds, wording and markdown identical.** Same headings, same
   table columns, same number formatting (`%+.1f%%`, `%+.2f`, `number_format(...,
   2)`), same section ordering. A future diff between the old command's
   markdown and the new report's markdown, run against the same input,
   should be empty.

5. **The command's console table becomes `data` + `summary`.** Whatever the
   original `renderTable()`/`renderSummary()` printed, put the same
   structured rows in `ReportResult::data` so the site's thin wrapper can
   print an equivalent table itself (the kit has no `$this->table()` — it
   isn't a console command). `summary` is the one-line version for a UI
   badge or a log line.

6. **Options mapping.** The artisan `--flag-name` becomes `$options['flag_name']`
   (dashes to underscores). `ReportRegistry::get($key)['options']`
   documents the exact set and default for your report — match it. Read
   options exactly like the reference port: `(int) ($options['window'] ?? 28)`,
   never assume every key is present.

7. **Write the unit test** in `tests/Unit/Reports/<Name>ReportTest.php` using
   the fakes in `tests/Unit/Reports/Fakes/` (one per interface, array-backed,
   fluent `with*()` setters — do not write a new fake for an interface that
   already has one). Cover: the empty-data case, each threshold actually
   gating (a row just below vs. just above), row ordering, and the exact
   markdown headings/section counts. Freeze time with
   `Carbon::setTestNow()` in `setUp()` / clear it in `tearDown()`, exactly
   like `ContentDecayReportTest`.

8. **Run `vendor/bin/phpunit` and `php -l` your new file(s).** Both must be
   clean before you're done.

## The interfaces, method by method

Full docblocks with WHY live on each interface file — this is the quick
index. Every method's exact return shape is documented on the interface
itself; don't duplicate it here, read the file.

| Interface (`src/Reports/Contracts/`) | Capability key | Used by |
|---|---|---|
| `QueryMetricsReader` | `query_metrics` | content-decay (reference port), content-gap, health (rankings pillar) |
| `PsiSnapshotReader` | `psi_snapshots` | cwv-template |
| `PageFetcher` (+ `Reports\PageFetchResult`) | `page_fetcher` | gbp-parity, internal-link-suggest, schema-audit, health-check, area-pages-audit |
| `SiteCatalog` | `site_catalog` | gbp-parity, internal-link-suggest, schema-audit, health-check, area-pages-audit |
| `SiteIdentity` | `site_identity` | gbp-parity |
| `AreaCatalog` | `area_catalog` | health (on-page pillar), area-pages-audit |
| `HealthDataReader` | `health_data` | health |
| `ClarityMetricsReader` | `clarity_metrics` | clarity-health |
| `Psr\SimpleCache\CacheInterface` (PSR-16, no kit wrapper) | `cache` | content-decay (reference port), schema-audit |

`ReportRegistry::REPORTS[$key]['requires']` is the authoritative list per
report — it's what a site checks before ever calling `generate()`.

### `SiteCatalog::sitemapUrls()` returns an UNFILTERED list

Four commands fetch the site's `sitemap.xml` and regex out every `<loc>`,
then each applies its OWN extension filter before slicing to its own
`--limit`. The filters differ — do not let a shared filter creep into
`SiteCatalog` itself:

| Command | Filter |
|---|---|
| `SeoGbpParity` | none — scans every `<loc>` for a `/services/{slug}` match |
| `SeoInternalLinkSuggest` | drops `txt,xml,json,csv,webmanifest,ico,png,jpe?g,webp,gif,svg,pdf,mp4,mp3` |
| `SeoSchemaAudit` | drops `txt,xml,json,csv,webmanifest,ico,png,jpg,jpeg,webp,gif,svg,pdf,mp4,mp3` (same set, listed differently) |
| `SeoHealthCheck` | keeps everything EXCEPT `json,xml,txt,csv,rss,atom,pdf,jpg,jpeg,png,webp,gif,svg,ico,css,js,map,webmanifest` |

Re-apply the ORIGINAL command's own filter inside that report, on the raw
list `SiteCatalog::sitemapUrls()` gives you.

### `QueryMetricsReader::pageMetrics()` and the health report's rankings pillar

`HealthReport`'s local-rankings pillar reuses `pageMetrics()` for its
"all-pages visibility (28 days)" sub-score, but `SeoHealth`'s original raw
query additionally filters out rows with a null/empty `page` and requires
`impressions > 0` (the interface's rows never need that filter for
content-decay, since `GscQueryMetric` rows always carry a page in practice
there). Apply that filter in `HealthReport` itself after calling
`pageMetrics()` — don't add a second, near-duplicate interface method for
one extra `WHERE` clause.

### `HealthReport` is the biggest port — five pillars, five sub-reads

- **On-page**: `HealthDataReader::imageAltCoverage()` (image half) +
  `AreaCatalog::areas()`'s `content_complete` (area half). Both `null`
  (unmeasured, not zero) when totals are 0 for both — see
  `SeoHealth::scoreOnPage()`'s own comment on why an empty tenant must not
  score 100.
- **Internal linking**: `HealthDataReader::internalLinkAuditLastRunAt()`.
- **GBP activity**: `HealthDataReader::gbpActivity()`.
- **Local rankings**: `HealthDataReader::latestRankSnapshots()` (the rank
  tracker half) + `QueryMetricsReader::pageMetrics()` (the GSC page-level
  half, see above) — `SeoHealth` blends both with the same 0.6/0.4 weights.
- **Freshness**: `HealthDataReader::freshnessSignals()`.
- **The health ledger** (`appendHealthLedger()` in the original): read with
  `HealthDataReader::healthLedger()`, merge/sort/prune to 120 entries
  INSIDE the report (the kit owns that algorithm), write back with
  `HealthDataReader::putHealthLedger()`.

Keep `SeoHealth`'s "average only the measured pillars" rule, its bar/grade
helpers, and its exact markdown table shape.

### The `cache` capability: no logger in the kit

`SeoContentDecay` and `SeoSchemaAudit` both use Laravel's `Cache::add()` to
suppress a repeated `logger()->warning()`/`info()` call within a rolling
window. The kit has no logger dependency — see `ContentDecayReport::alert()`
for the pattern: compute the same dedup cache key, use PSR-16
`has()`/`set()` in place of `Cache::add()`'s atomicity (fine for a
single-process artisan run), and return the suppressed/level/message
decision in `ReportResult::data['alert']` instead of calling `logger()`
directly. The site's thin wrapper reads `data['alert']` and logs it.

## How a site wraps a report

Thin artisan command (mirrors what `SeoContentDecay` used to do, minus the
algorithm):

```php
class SeoContentDecay extends Command
{
    protected $signature = 'seo:content-decay
        {--window=28} {--min-impressions=50} {--click-drop=20} {--pos-drop=2} {--limit=40}
        {--markdown}';

    public function handle(ContentDecayReport $report): int
    {
        $result = $report->generate([
            'window' => (int) $this->option('window'),
            'min_impressions' => (int) $this->option('min-impressions'),
            'click_drop' => (int) $this->option('click-drop'),
            'pos_drop' => (float) $this->option('pos-drop'),
            'limit' => (int) $this->option('limit'),
        ]);

        if ($result->status === ReportResult::STATUS_ERROR) {
            $this->error($result->error);
            return self::FAILURE;
        }

        $this->line($result->summary);
        // ...print $result->data as a table, same shape the old renderTable() used...

        if ($alert = $result->data['alert'] ?? null) {
            if (! $alert['suppressed'] && $alert['level'] === 'warning') {
                logger()->warning($alert['message'], $result->data);
            } elseif (! $alert['suppressed'] && $alert['level'] === 'info') {
                logger()->info($alert['message'], $result->data);
            }
        }

        if ($this->option('markdown')) {
            Storage::disk('local')->put(SeoStorage::path('reports/content-decay.md'), $result->markdown);
        }

        return self::SUCCESS;
    }
}
```

Adapter (site-specific, implements the interface over real models):

```php
final class EloquentQueryMetricsReader implements QueryMetricsReader
{
    public function pageMetrics(string $from, string $to): array
    {
        return GscQueryMetric::query()
            ->whereBetween('date', [$from, $to])
            ->selectRaw('page, SUM(impressions) as impr, SUM(clicks) as clicks, SUM(impressions * position) as weighted_pos')
            ->groupBy('page')
            ->get()
            ->map(fn ($r) => [
                'page' => $r->page,
                'impressions' => (int) $r->impr,
                'clicks' => (int) $r->clicks,
                'position' => $r->impr > 0 ? round(((float) $r->weighted_pos) / $r->impr, 2) : null,
            ])
            ->all();
    }

    // queryPageMetrics() similarly...
}
```

Bind it in `AppServiceProvider`:

```php
$this->app->bind(QueryMetricsReader::class, EloquentQueryMetricsReader::class);
```

A site that cannot provide an interface (e.g. jpeterson-design's
`AreaCatalog`, which has no per-city landing-page architecture) simply
never binds it. `ReportRegistry::availableFor()` then excludes any report
whose `requires` includes that key, and the site shows an honest
"not available for this site" state instead of a caught
`CommandNotFoundException` — the actual bug this whole port exists to fix.

## If an interface doesn't cover your report

**Never edit an existing interface or an existing fake.** If your report
needs data none of the nine interfaces offers, add a NEW interface file
under `Contracts/` (plus its own new capability key and its own new fake
under `Fakes/`) instead. Every other report and every already-ported test
depends on the existing interfaces staying exactly as they are — a
"small addition" to `HealthDataReader` for your report is exactly the kind
of change that breaks a sibling agent's in-flight work on `HealthReport`.
