<?php

namespace SsSystems\Platform\Seo\Bing;

/**
 * Where BingSync's rows land. The kit computes every row; each site's own
 * implementation is the only place that writes one — gs.construction's
 * rows are tenant-scoped through BelongsToSite, jpeterson-design's are a
 * single site's plain models. Bound once in each site's AppServiceProvider.
 */
interface BingWriter
{
    /**
     * Insert or update one query/day row, keyed on its dim_hash (see
     * BingSync::queryStatRow for the hash).
     *
     * @param  array{date: string, site_url: string, query: string, impressions: int, clicks: int, position: float, dim_hash: string}  $row
     * @return 'inserted'|'updated'
     */
    public function upsertQueryStat(array $row): string;

    /**
     * Insert or update one day's true totals. Finding the existing row is
     * the site's job, and it must be a whereDate() lookup, not a plain
     * string match on the date column: Eloquent's `date` cast writes a full
     * 'Y-m-d H:i:s', only MySQL's DATE type truncates it back, and under
     * the sqlite the test suites run against a string match always misses
     * and a re-sync inserts a duplicate. Same rule as SearchConsoleWriter.
     *
     * @param  array{clicks: int, impressions: int, ctr: float}  $totals
     */
    public function upsertDailyTotal(string $date, string $siteUrl, array $totals): void;
}
