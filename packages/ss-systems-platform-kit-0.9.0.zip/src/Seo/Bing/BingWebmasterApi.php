<?php

namespace SsSystems\Platform\Seo\Bing;

use Illuminate\Http\Client\Factory;

/**
 * Bing Webmaster Tools API — free, a plain API key on the query string.
 *
 *   https://learn.microsoft.com/en-us/bingwebmaster/getting-access
 *   https://learn.microsoft.com/en-us/dotnet/api/microsoft.bing.webmaster.api.interfaces.iwebmasterapi.getrankandtrafficstats
 *
 * Two calls: GetQueryStats (per query per day) and GetRankAndTrafficStats
 * (the real daily totals — GetQueryStats omits the clicks and impressions of
 * queries Bing anonymises, so its per-day sums under-report against the
 * dashboard; the headline numbers and the trend come from the totals).
 *
 * The HTTP client is Laravel's, handed in so a site passes the one behind
 * its Http facade (and Http::fake() in its tests applies), and so a kit test
 * can fake it with no container at all. Nothing here logs: a failure comes
 * back as null with lastError() set, and the site decides what to do.
 */
final class BingWebmasterApi implements BingWebmasterClient
{
    public const API_BASE = 'https://ssl.bing.com/webmaster/api.svc/json';

    private ?string $lastError = null;

    public function __construct(
        private readonly ?string $apiKey,
        private readonly string $siteUrl,
        private readonly ?Factory $http = null,
        private readonly int $timeoutSeconds = 45,
    ) {}

    public function isConfigured(): bool
    {
        return trim((string) $this->apiKey) !== '' && trim($this->siteUrl) !== '';
    }

    public function siteUrl(): string
    {
        return $this->siteUrl;
    }

    public function queryStats(): ?array
    {
        $rows = $this->get('GetQueryStats');
        if ($rows === null) {
            return null;
        }

        $out = [];
        foreach ($rows as $row) {
            $date = self::parseMsDate($row['Date'] ?? null);
            if ($date === null) {
                continue;
            }
            $out[] = [
                'date' => $date,
                'site_url' => $this->siteUrl,
                'query' => (string) ($row['Query'] ?? ''),
                'impressions' => (int) ($row['Impressions'] ?? 0),
                'clicks' => (int) ($row['Clicks'] ?? 0),
                'position' => (float) ($row['AvgImpressionPosition'] ?? $row['AvgClickPosition'] ?? 0),
            ];
        }

        return $out;
    }

    public function rankAndTrafficStats(): ?array
    {
        $rows = $this->get('GetRankAndTrafficStats');
        if ($rows === null) {
            return null;
        }

        $out = [];
        foreach ($rows as $row) {
            $date = self::parseMsDate($row['Date'] ?? null);
            if ($date === null) {
                continue;
            }
            $out[] = [
                'date' => $date,
                'site_url' => $this->siteUrl,
                'impressions' => (int) ($row['Impressions'] ?? 0),
                'clicks' => (int) ($row['Clicks'] ?? 0),
            ];
        }

        return $out;
    }

    public function lastError(): ?string
    {
        return $this->lastError;
    }

    /**
     * Bing writes a date as "/Date(1747353600000)/" — milliseconds since the
     * epoch, at midnight UTC. Read it in UTC: through the app's own timezone
     * (Chicago, six hours behind) that midnight is still the evening before,
     * and every row would land on the wrong day.
     */
    public static function parseMsDate(?string $raw): ?string
    {
        if (! $raw || ! preg_match('/Date\((-?\d+)/', $raw, $m)) {
            return null;
        }

        return gmdate('Y-m-d', intdiv((int) $m[1], 1000));
    }

    /** @return array<int, array<string, mixed>>|null */
    private function get(string $method): ?array
    {
        $http = $this->http ?? new Factory();

        try {
            $response = $http->timeout($this->timeoutSeconds)->get(self::API_BASE.'/'.$method, [
                'siteUrl' => $this->siteUrl,
                'apikey' => (string) $this->apiKey,
            ]);
        } catch (\Throwable $e) {
            $this->lastError = $method.': '.$e->getMessage();

            return null;
        }

        if (! $response->successful()) {
            $this->lastError = $method.' answered '.$response->status().': '.mb_substr(trim($response->body()), 0, 300);

            return null;
        }

        $this->lastError = null;
        $data = $response->json('d');

        return is_array($data) ? array_values($data) : [];
    }
}
