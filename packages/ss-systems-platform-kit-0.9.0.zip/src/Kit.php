<?php

namespace SsSystems\Platform;

/**
 * The drift trip-wire.
 *
 * Both sites report this from their /ping payload, and the central admin flags
 * the moment jpeterson-design and gs.construction disagree. That is the check
 * that replaces "remember to copy the file to the other repo" — a missed bump
 * is loud (one site visibly behind), where a missed copy was silent.
 */
final class Kit
{
    public const VERSION = '0.9.0';
}
