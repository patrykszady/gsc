<?php

namespace SsSystems\Platform\Social;

use Illuminate\Support\Carbon;
use Random\Engine\Mt19937;
use Random\Randomizer;

/**
 * A platform's posting plan for any ISO week — the days, and a time on each —
 * computed deterministically from its cadence, so a re-run, a missed tick or
 * two ticks seconds apart all recompute the identical plan instead of drifting
 * or double-posting. One implementation for every site (moved here from
 * gs.construction's and jpeterson-design's identical copies, 2026-09-23).
 *
 * THE DAYS (random mode — no explicit days chosen):
 *
 *   1. Never two posts on back-to-back days, INCLUDING a Sunday post followed
 *      by the next Monday's, unless the count makes it unavoidable: seven
 *      days hold at most three posts with a day between each when the weeks
 *      run on into each other, so four a week puts one pair side by side
 *      (on whichever days the week's seed picks), and five or more more.
 *   2. Spread as evenly as the count allows. Every gap between two posts —
 *      within a week and across into the next — is kept in the band the
 *      average spacing implies: two a week always land three or four days
 *      apart, three a week two or three, one a week four to ten (it wanders
 *      a little rather than sitting on one weekday). Before this (Patryk,
 *      2026-09-23) the days were a plain shuffle, and two posts a week could
 *      land on a Friday and the Saturday after it.
 *   3. Still random: among the plans that are equally well spread, the week's
 *      seed picks one, so the days move from week to week.
 *
 * Rule 1 across the weekend needs last week's last day, so a week's days
 * follow from the week before it, which follows from the week before that,
 * back to a fixed first week (CHAIN_START_MONDAY). Fixed, not "a few weeks
 * back": a moving start would compute last week differently from how last
 * week computed itself, and the Sunday-to-Monday guarantee would not hold.
 * A year is ~52 small steps, cached per planner instance; a cold plan ten
 * years out measured 17ms (2026-09-23). If that ever matters, cache resolved
 * weeks somewhere that outlives a request — never move the start.
 *
 * Instagram and Facebook never land on the same day. Their days are chosen
 * TOGETHER from one seed (site + week, no platform), each spread by the rules
 * above and the two sets disjoint, so either platform's call — each passing
 * the other's cadence as $siblingCadence — computes the same pair. Without a
 * sibling cadence the sibling is assumed to post as often as this platform.
 *
 * EXPLICIT DAYS ("These days") are the owner's choice and are honoured as
 * given, capped to posts-per-week — even if they are side by side.
 *
 * THE TIME on each day is drawn from the platform's own stream (site +
 * platform + week), so Instagram and Facebook do not post at the same clock
 * time week after week.
 */
class AutomationPlanner
{
    /** Platforms that must never land on the same day as each other. */
    public const META_PLATFORMS = ['instagram', 'facebook'];

    /**
     * The first week every chain starts from: Monday of ISO 2026-W01. Never
     * move it — every week's days follow from it, so moving it reshuffles
     * every plan, past weeks included.
     */
    public const CHAIN_START_MONDAY = '2025-12-29';

    /** Cost of one back-to-back pair: dominates everything else. */
    private const ADJACENT = 1000;

    /** Cost per day a gap falls short of the even-spacing band. */
    private const TOO_CLOSE = 10;

    /** Cost per day a gap runs past the band. */
    private const TOO_FAR = 1;

    /** @var array<string, list<int>> days per chain key + week, per instance */
    private array $days = [];

    /** @var array<string, array{0: list<int>, 1: list<int>}> Instagram/Facebook day pairs per chain key + week */
    private array $pairs = [];

    public function __construct(protected string $timezone = 'America/Chicago') {}

    public function timezone(): string
    {
        return $this->timezone;
    }

    /**
     * This week's plan for the API: week label, every slot (with whether it
     * has already passed), and the next upcoming slot (which may fall in
     * next week once this week's are all done).
     *
     * @param  array{per_week:int, days:?array<int,int>, window:array{start:string,end:string}}  $cadence
     * @param  ?array{per_week:int, days:?array<int,int>, window:array{start:string,end:string}}  $siblingCadence  the OTHER meta platform's cadence (instagram<->facebook only)
     * @return array{week: string, slots: list<array{day:int, date:string, at:string, done:bool}>, next_at: ?string}
     */
    public function plan(string $siteSlug, string $platform, array $cadence, ?Carbon $now = null, ?array $siblingCadence = null): array
    {
        $now = $this->normalize($now);
        $slots = $this->weekSlots($siteSlug, $platform, $cadence, $now, $siblingCadence);

        $decorated = array_map(function (array $slot) use ($now) {
            $slot['done'] = $this->slotAt($slot)->lessThanOrEqualTo($now);

            return $slot;
        }, $slots);

        $nextAt = $this->nextAt($siteSlug, $platform, $cadence, $now, $siblingCadence);

        return [
            'week' => $this->weekLabel($now),
            'slots' => $decorated,
            'next_at' => $nextAt?->toIso8601String(),
        ];
    }

    /**
     * The slot id ("Y-m-d H:i") due within the last 5 minutes, or null.
     *
     * Half-open (now-5min, now] window: with ticks running every 5 minutes on
     * the cron grid, every slot minute falls inside exactly one tick's window,
     * so a slot fires exactly once even across two ticks straddling its minute.
     */
    public function due(string $siteSlug, string $platform, array $cadence, ?Carbon $now = null, ?array $siblingCadence = null): ?string
    {
        $now = $this->normalize($now);
        $windowStart = $now->copy()->subMinutes(5);

        foreach ($this->weekSlots($siteSlug, $platform, $cadence, $now, $siblingCadence) as $slot) {
            $slotAt = $this->slotAt($slot);
            if ($slotAt->greaterThan($windowStart) && $slotAt->lessThanOrEqualTo($now)) {
                return $slot['date'].' '.$slot['at'];
            }
        }

        return null;
    }

    /** The next upcoming slot, checking this week then next week. */
    public function nextAt(string $siteSlug, string $platform, array $cadence, ?Carbon $now = null, ?array $siblingCadence = null): ?Carbon
    {
        $now = $this->normalize($now);

        for ($weekOffset = 0; $weekOffset <= 1; $weekOffset++) {
            $reference = $now->copy()->addWeeks($weekOffset);

            foreach ($this->weekSlots($siteSlug, $platform, $cadence, $reference, $siblingCadence) as $slot) {
                $slotAt = $this->slotAt($slot);
                if ($slotAt->greaterThan($now)) {
                    return $slotAt;
                }
            }
        }

        return null;
    }

    /**
     * Whether a due slot should be held back because the platform last posted
     * on the same or the previous calendar day — the tick's backstop for the
     * "never back-to-back" rule when the planned days themselves can change
     * under it: a cadence edit mid-week, or this planner replacing the old
     * shuffle (2026-09-23) after a post had already gone out under the old
     * plan. Only for random days at three or fewer a week, where a planned
     * slot is never within a day of the last one, so it can only ever stop
     * a stray; days the owner picked, and crowded weeks that plan side-by-
     * side days on purpose, are left alone.
     */
    public function tooSoonAfter(array $cadence, ?Carbon $lastDispatchedAt, ?Carbon $now = null): bool
    {
        if ($lastDispatchedAt === null || self::fixedDays($cadence) !== null || self::perWeek($cadence) > 3) {
            return false;
        }

        $today = $this->normalize($now)->startOfDay();
        $last = $lastDispatchedAt->copy()->setTimezone($this->timezone)->startOfDay();

        return $last->greaterThanOrEqualTo($today->copy()->subDay());
    }

    /**
     * The ISO weekdays (1 = Monday … 7 = Sunday) this platform posts on in the
     * week containing $reference, ascending.
     *
     * @param  ?array{per_week:int, days:?array<int,int>, window:array{start:string,end:string}}  $siblingCadence
     * @return list<int>
     */
    public function days(string $siteSlug, string $platform, array $cadence, Carbon $reference, ?array $siblingCadence = null): array
    {
        $reference = $this->normalize($reference);
        $fixed = self::fixedDays($cadence);
        if ($fixed !== null) {
            return $fixed;
        }

        $monday = $reference->copy()->startOfWeek(Carbon::MONDAY)->startOfDay();

        if (in_array($platform, self::META_PLATFORMS, true)) {
            $sibling = $siblingCadence ?? ['per_week' => self::perWeek($cadence), 'days' => null];
            $instagram = $platform === 'instagram' ? $cadence : $sibling;
            $facebook = $platform === 'instagram' ? $sibling : $cadence;

            [$instagramDays, $facebookDays] = $this->metaPair($siteSlug, $instagram, $facebook, $monday);

            return $platform === 'instagram' ? $instagramDays : $facebookDays;
        }

        return $this->chain($siteSlug, $platform, self::perWeek($cadence), $monday);
    }

    /**
     * How many days without a post before the tick posts anyway: one day
     * longer than the longest gap the plan ever leaves, so it only fires when
     * a planned post did not go out (a failed publish, a held slot, a photo
     * with nowhere to go). Worked out from the rhythm — no setting (Patryk,
     * 2026-09-23: "this should be automatically done in the backend"). For
     * days the owner picked, the longest gap between them, round the week.
     */
    public function catchUpAfterDays(array $cadence): int
    {
        $fixed = self::fixedDays($cadence);
        if ($fixed === null) {
            return self::spacingBand(self::perWeek($cadence))[1] + 1;
        }

        $longest = 7 - end($fixed) + $fixed[0];
        for ($i = 1; $i < count($fixed); $i++) {
            $longest = max($longest, $fixed[$i] - $fixed[$i - 1]);
        }

        return $longest + 1;
    }

    /**
     * The even-spacing band for a count per week: the gaps (in days) between
     * consecutive posts should fall in [low, high]. One a week wanders within
     * four to ten days of the last post rather than sitting on one weekday.
     *
     * @return array{0:int, 1:int}
     */
    public static function spacingBand(int $perWeek): array
    {
        $perWeek = max(1, min(7, $perWeek));

        return $perWeek === 1
            ? [4, 10]
            : [max(1, intdiv(7, $perWeek)), (int) ceil(7 / $perWeek)];
    }

    /**
     * The {day, date, at} slots for the ISO week containing $reference — no
     * "done" flag (that depends on the caller's $now, which may differ from
     * $reference when peeking at next week).
     *
     * @return list<array{day:int, date:string, at:string}>
     */
    protected function weekSlots(string $siteSlug, string $platform, array $cadence, Carbon $reference, ?array $siblingCadence = null): array
    {
        $weekLabel = $this->weekLabel($reference);
        $timeRandomizer = new Randomizer(new Mt19937(crc32(sprintf('%s|%s|%s', $siteSlug, $platform, $weekLabel))));

        $days = $this->days($siteSlug, $platform, $cadence, $reference, $siblingCadence);

        [$startMinutes, $endMinutes] = $this->windowMinutes($cadence['window'] ?? []);
        $weekStart = $reference->copy()->startOfWeek(Carbon::MONDAY);

        $slots = [];
        foreach ($days as $day) {
            $minute = $endMinutes > $startMinutes
                ? $timeRandomizer->getInt($startMinutes, $endMinutes)
                : $startMinutes;

            $slots[] = [
                'day' => $day,
                'date' => $weekStart->copy()->addDays($day - 1)->format('Y-m-d'),
                'at' => sprintf('%02d:%02d', intdiv($minute, 60), $minute % 60),
            ];
        }

        usort($slots, fn ($a, $b) => $a['date'] <=> $b['date']);

        return $slots;
    }

    /**
     * One platform's days for the week starting $monday, following on from
     * every week before it back to CHAIN_START_MONDAY.
     *
     * @return list<int>
     */
    private function chain(string $siteSlug, string $platform, int $perWeek, Carbon $monday): array
    {
        $key = "{$siteSlug}|{$platform}|{$perWeek}";
        $previousLast = null;
        $days = [];

        foreach ($this->weeksUpTo($monday) as $week) {
            $cacheKey = "{$key}|{$week}";
            if (! isset($this->days[$cacheKey])) {
                $rng = new Randomizer(new Mt19937(crc32(sprintf('%s|%s|%s', $siteSlug, $platform, $week))));
                $this->days[$cacheKey] = $this->pick($rng, $perWeek, $previousLast);
            }
            $days = $this->days[$cacheKey];
            $previousLast = end($days) ?: null;
        }

        return $days;
    }

    /**
     * Instagram's and Facebook's days for the week starting $monday, chosen
     * together: each spread by the rules, the two disjoint, from one seed
     * with no platform in it — so both platforms compute the same pair.
     *
     * @return array{0: list<int>, 1: list<int>}
     */
    private function metaPair(string $siteSlug, array $instagram, array $facebook, Carbon $monday): array
    {
        $igFixed = self::fixedDays($instagram);
        $fbFixed = self::fixedDays($facebook);
        $igCount = self::perWeek($instagram);
        $fbCount = self::perWeek($facebook);
        $key = sprintf('%s|meta|%s|%d|%s|%d', $siteSlug, $igFixed === null ? 'r' : implode(',', $igFixed), $igCount, $fbFixed === null ? 'r' : implode(',', $fbFixed), $fbCount);

        $igLast = null;
        $fbLast = null;
        $pair = [[], []];

        foreach ($this->weeksUpTo($monday) as $week) {
            $cacheKey = "{$key}|{$week}";
            if (! isset($this->pairs[$cacheKey])) {
                $rng = new Randomizer(new Mt19937(crc32(sprintf('%s|meta-social|%s', $siteSlug, $week))));
                $this->pairs[$cacheKey] = $this->pickPair($rng, $igFixed, $igCount, $igLast, $fbFixed, $fbCount, $fbLast);
            }
            $pair = $this->pairs[$cacheKey];
            $igLast = end($pair[0]) ?: null;
            $fbLast = end($pair[1]) ?: null;
        }

        return $pair;
    }

    /**
     * The best-spread set of $perWeek days, avoiding $exclude, given the
     * previous week's last day; ties broken by the week's seed.
     *
     * @param  list<int>  $exclude
     * @return list<int>
     */
    private function pick(Randomizer $rng, int $perWeek, ?int $previousLast, array $exclude = []): array
    {
        $best = null;
        $bestSets = [];

        foreach (self::combinations($perWeek) as $set) {
            if ($exclude !== [] && array_intersect($set, $exclude) !== []) {
                continue;
            }
            $cost = self::cost($set, $previousLast, $perWeek);
            if ($best === null || $cost < $best) {
                $best = $cost;
                $bestSets = [$set];
            } elseif ($cost === $best) {
                $bestSets[] = $set;
            }
        }

        // Only possible when $exclude leaves too few days (Instagram and
        // Facebook together asking for more than seven): share days rather
        // than drop posts.
        if ($bestSets === []) {
            return $this->pick($rng, $perWeek, $previousLast);
        }

        return $bestSets[$rng->getInt(0, count($bestSets) - 1)];
    }

    /**
     * @param  ?list<int>  $igFixed
     * @param  ?list<int>  $fbFixed
     * @return array{0: list<int>, 1: list<int>}
     */
    private function pickPair(Randomizer $rng, ?array $igFixed, int $igCount, ?int $igLast, ?array $fbFixed, int $fbCount, ?int $fbLast): array
    {
        if ($igFixed !== null && $fbFixed !== null) {
            return [$igFixed, $fbFixed];
        }
        if ($igFixed !== null) {
            return [$igFixed, $this->pick($rng, $fbCount, $fbLast, $igFixed)];
        }
        if ($fbFixed !== null) {
            return [$this->pick($rng, $igCount, $igLast, $fbFixed), $fbFixed];
        }

        $best = null;
        $bestPairs = [];
        $fbSets = [];
        foreach (self::combinations($fbCount) as $fb) {
            $fbSets[] = [$fb, self::mask($fb), self::cost($fb, $fbLast, $fbCount)];
        }

        foreach (self::combinations($igCount) as $ig) {
            $igMask = self::mask($ig);
            $igCost = self::cost($ig, $igLast, $igCount);
            foreach ($fbSets as [$fb, $fbMask, $fbCost]) {
                if (($igMask & $fbMask) !== 0) {
                    continue;
                }
                $cost = $igCost + $fbCost;
                if ($best === null || $cost < $best) {
                    $best = $cost;
                    $bestPairs = [[$ig, $fb]];
                } elseif ($cost === $best) {
                    $bestPairs[] = [$ig, $fb];
                }
            }
        }

        if ($bestPairs === []) {
            // More than seven posts between them: they cannot all be on
            // separate days. Each keeps its own spacing; days may coincide.
            return [$this->pick($rng, $igCount, $igLast), $this->pick($rng, $fbCount, $fbLast)];
        }

        return $bestPairs[$rng->getInt(0, count($bestPairs) - 1)];
    }

    /**
     * How badly a set of days breaks the rules: back-to-back pairs dominate,
     * then gaps short of the even-spacing band, then gaps past it. The gap
     * from last week's last day counts like any other.
     *
     * @param  list<int>  $days  ascending
     */
    private static function cost(array $days, ?int $previousLast, int $perWeek): int
    {
        [$low, $high] = self::spacingBand($perWeek);

        $gaps = [];
        for ($i = 1; $i < count($days); $i++) {
            $gaps[] = $days[$i] - $days[$i - 1];
        }
        if ($previousLast !== null && $days !== []) {
            $gaps[] = 7 - $previousLast + $days[0];
        }

        $cost = 0;
        foreach ($gaps as $gap) {
            if ($gap <= 1) {
                $cost += self::ADJACENT;
            }
            if ($gap < $low) {
                $cost += self::TOO_CLOSE * ($low - $gap);
            }
            if ($gap > $high) {
                $cost += self::TOO_FAR * ($gap - $high);
            }
        }

        return $cost;
    }

    /**
     * Every ascending set of $count distinct weekdays (1..7).
     *
     * @return list<list<int>>
     */
    private static function combinations(int $count): array
    {
        static $cache = [];
        $count = max(1, min(7, $count));

        if (! isset($cache[$count])) {
            $sets = [];
            for ($mask = 1; $mask < 128; $mask++) {
                if (substr_count(decbin($mask), '1') !== $count) {
                    continue;
                }
                $set = [];
                for ($bit = 0; $bit < 7; $bit++) {
                    if ($mask & (1 << $bit)) {
                        $set[] = $bit + 1;
                    }
                }
                $sets[] = $set;
            }
            $cache[$count] = $sets;
        }

        return $cache[$count];
    }

    /** @param  list<int>  $days */
    private static function mask(array $days): int
    {
        $mask = 0;
        foreach ($days as $day) {
            $mask |= 1 << ($day - 1);
        }

        return $mask;
    }

    /**
     * ISO week labels from CHAIN_START_MONDAY up to and including the week
     * starting $monday. A week before the chain start is computed on its own.
     *
     * @return \Generator<int, string>
     */
    private function weeksUpTo(Carbon $monday): \Generator
    {
        $cursor = Carbon::parse(self::CHAIN_START_MONDAY, $this->timezone)->startOfDay();
        $target = $monday->copy()->setTimezone($this->timezone)->startOfDay();

        if ($target->lessThan($cursor)) {
            yield $this->weekLabel($target);

            return;
        }

        while ($cursor->lessThanOrEqualTo($target)) {
            yield $this->weekLabel($cursor);
            $cursor = $cursor->addWeek();
        }
    }

    /** @return ?list<int> */
    private static function fixedDays(array $cadence): ?array
    {
        $configured = $cadence['days'] ?? null;
        if (! is_array($configured) || $configured === []) {
            return null;
        }

        $days = array_values(array_unique(array_map('intval', $configured)));
        $days = array_values(array_filter($days, fn (int $d) => $d >= 1 && $d <= 7));
        sort($days);

        return array_slice($days, 0, self::perWeek($cadence));
    }

    private static function perWeek(array $cadence): int
    {
        return max(1, min(7, (int) ($cadence['per_week'] ?? 1)));
    }

    /** @param array{start?:string,end?:string} $window */
    protected function windowMinutes(array $window): array
    {
        [$startH, $startM] = array_pad(explode(':', $window['start'] ?? '09:00'), 2, '0');
        [$endH, $endM] = array_pad(explode(':', $window['end'] ?? '17:00'), 2, '0');

        return [
            ((int) $startH) * 60 + (int) $startM,
            ((int) $endH) * 60 + (int) $endM,
        ];
    }

    /** @param array{date:string, at:string} $slot */
    protected function slotAt(array $slot): Carbon
    {
        return Carbon::parse($slot['date'].' '.$slot['at'], $this->timezone);
    }

    protected function weekLabel(Carbon $reference): string
    {
        return sprintf('%04d-W%02d', (int) $reference->format('o'), (int) $reference->format('W'));
    }

    protected function normalize(?Carbon $now): Carbon
    {
        return ($now ?? Carbon::now($this->timezone))->copy()->setTimezone($this->timezone);
    }
}
