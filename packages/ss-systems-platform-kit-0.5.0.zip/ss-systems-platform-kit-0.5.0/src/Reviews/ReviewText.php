<?php

namespace SsSystems\Platform\Reviews;

use Illuminate\Support\Carbon;

/**
 * The text rules a review import needs: what counts as the same review on
 * two sites, what a scraped card becomes before it is stored, and how a
 * business name compares with a page heading.
 *
 * Pure functions, shared by every site's importers so that "same review"
 * means one thing everywhere.
 */
final class ReviewText
{
    /**
     * HTML entities decoded, in case a stored review kept them: "couldn&#39;t"
     * and "couldn't" are the same review and must compare equal. Angi
     * double-encodes, so decode until it settles.
     */
    public static function decodeEntities(string $value): string
    {
        for ($pass = 0; $pass < 3; $pass++) {
            $decoded = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if ($decoded === $value) {
                break;
            }
            $value = $decoded;
        }

        return $value;
    }

    /**
     * A review body as prose.
     *
     * Angi's text arrives with its markup escaped — "&lt;br /&gt;" for the
     * line breaks people typed — and a corruption of its own, "and quot;"
     * where a review had a double quote. Entities are decoded, the breaks
     * become newlines, any other tag is dropped, and "and quot;" is put back.
     */
    public static function cleanBody(string $value): string
    {
        $text = (string) preg_replace('/and (quot|amp|lt|gt|apos|nbsp|#\\d+|#x[0-9a-f]+);/i', '&$1;', $value);
        $text = self::decodeEntities($text);
        $text = (string) preg_replace(['/<br\\s*\\/?>/i', '/<\\/?p\\b[^>]*>/i'], "\n", $text);
        $text = strip_tags($text);
        $text = str_replace("\r", '', $text);
        $lines = array_map(fn (string $line) => trim((string) preg_replace('/[ \\t]+/', ' ', $line)), explode("\n", $text));

        return trim((string) preg_replace("/\\n{3,}/", "\n\n", implode("\n", $lines)));
    }

    /**
     * A person's name as a name: each word's first letter up, the rest down —
     * "TODD & KRISTEN M." and "don K." both come off Angi, and neither is how
     * a review should be signed on the site. Initials, "&", hyphens and
     * apostrophes are kept ("Mary-Jane O'Neil M.").
     */
    public static function properName(string $value): string
    {
        $name = mb_strtolower(trim((string) preg_replace('/\\s+/u', ' ', self::decodeEntities($value))));

        $name = (string) preg_replace_callback(
            '/(^|[\\s\\-\'’(])(\\p{L})/u',
            fn (array $m) => $m[1].mb_strtoupper($m[2]),
            $name,
        );

        // "William and Sheila P." — a conjunction inside a name is not a name.
        return (string) preg_replace_callback('/ (And|Or) /', fn (array $m) => mb_strtolower($m[0]), $name);
    }

    /** Letters, digits and single spaces only — punctuation and encoding differ between sites. */
    public static function comparable(?string $text, int $length = 160): string
    {
        $text = self::decodeEntities((string) $text);
        $text = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text) ?: $text;
        $text = (string) preg_replace('/[^a-zA-Z0-9 ]/', '', $text);
        $text = mb_strtolower((string) preg_replace('/\s+/', ' ', trim($text)));

        return mb_substr($text, 0, $length);
    }

    /** Letters and digits only, for comparing a business name with a URL slug or page heading. */
    public static function normalizeName(string $value): string
    {
        return (string) preg_replace('/[^a-z0-9]+/', '', mb_strtolower($value));
    }

    /**
     * A scraped Angi review as the site stores it, or null when it is not a
     * review at all.
     *
     * Angi lets a customer leave a rating without a write-up and publishes
     * the body as the word "unknown". That is a rating, not a review, and it
     * is dropped here as well as in the scraper — a payload captured by an
     * older scraper could still carry it.
     *
     * The date is whatever Angi gives: an ISO timestamp on the old page, a
     * month ("January 2015") on the new one, which lands on the first.
     *
     * @param  array<string, mixed>  $review
     * @return array{reviewer_name: string, review_description: string, review_date: ?Carbon, star_rating: ?int}|null
     */
    public static function normalizeAngiReview(array $review): ?array
    {
        $name = self::properName((string) ($review['reviewer_name'] ?? ''));
        $description = self::cleanBody((string) ($review['review_description'] ?? ''));
        if (strcasecmp($description, 'unknown') === 0) {
            $description = '';
        }
        // A React flight reference ("$43") that nobody resolved: a bug upstream,
        // never a review. Three such rows reached production on 2026-09-21.
        if (preg_match('/^\$[0-9a-z]+$/i', $description)) {
            $description = '';
        }
        if ($name === '' || $description === '') {
            return null;
        }

        $date = null;
        $rawDate = trim((string) ($review['review_date_raw'] ?? ''));
        if ($rawDate !== '') {
            try {
                $date = Carbon::parse($rawDate)->startOfDay();
            } catch (\Throwable) {
                $date = null;
            }
        }

        $rating = isset($review['star_rating']) ? (int) $review['star_rating'] : null;
        if ($rating !== null && ($rating < 1 || $rating > 5)) {
            $rating = null;
        }

        return [
            'reviewer_name' => $name,
            'review_description' => $description,
            'review_date' => $date,
            'star_rating' => $rating,
        ];
    }

    /**
     * One key per distinct review within a scrape.
     *
     * @param  array{reviewer_name: string, review_description: string, review_date: ?Carbon}  $payload
     */
    public static function payloadKey(array $payload): string
    {
        return mb_strtolower(trim($payload['reviewer_name']))
            .'|'.($payload['review_date']?->toDateString() ?? 'no-date')
            .'|'.self::comparable($payload['review_description']);
    }
}
