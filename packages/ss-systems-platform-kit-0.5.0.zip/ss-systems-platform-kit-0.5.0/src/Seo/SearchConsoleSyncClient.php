<?php

namespace SsSystems\Platform\Seo;

/**
 * What SearchConsoleSync needs from a site's Search Console service, on top
 * of the three methods SearchConsoleClient already asks for. The existing
 * interface stays untouched — SitemapStatus's app(SearchConsoleClient::class)
 * resolution keeps working exactly as it does today — this just adds the two
 * methods a full metrics sync needs and neither the sitemap check nor the
 * kit's earlier callers did.
 *
 * Each site's App\Services\GoogleSearchConsoleService already has a
 * querySearchAnalytics() method at this exact shape; siteUrl() is the one
 * genuinely new method each site adds, resolving to whatever that site
 * already uses to pick its own property (gsc: SearchConsoleProperty::url(),
 * jpeterson-design: a plain config() read).
 */
interface SearchConsoleSyncClient extends SearchConsoleClient
{
    /**
     * One page of Google's searchAnalytics.query results for the given
     * dimensions and date range.
     *
     * @param  array<int, string>  $dimensions
     * @return array<int, array<string, mixed>>|null  Google's raw rows, or null on failure (see getLastError()).
     */
    public function querySearchAnalytics(
        string $siteUrl,
        string $startDate,
        string $endDate,
        array $dimensions,
        int $rowLimit,
        int $startRow,
    ): ?array;

    /**
     * The site's own Search Console property URL. Resolved without needing a
     * live OAuth grant, so SearchConsoleSync can read it even to describe a
     * run that turns out to be skipped for lack of one.
     */
    public function siteUrl(): string;
}
