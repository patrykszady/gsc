<?php

namespace SsSystems\Platform\Seo;

/**
 * The window, the lag and the cadence for the Search Console sync — decided
 * once, here, so gs.construction, jpeterson-design and ss.systems' own
 * reconcile command all read the same numbers instead of each hardcoding a
 * copy that happens to agree today. A site must never grow its own version
 * of this rule.
 */
final class SearchConsoleSyncRule
{
    /**
     * How many days back a sync covers by default. Google's own search
     * analytics keeps revising the last couple of days as more data lands,
     * so a short window looks fine right up until it quietly misses days
     * that were still filling in when a narrower sync ran. Do not shrink
     * this without checking why first.
     */
    public const DEFAULT_DAYS = 7;

    /**
     * Google reports search-analytics data two to three days late, so the
     * window's end is shifted back this many days rather than ending today.
     */
    public const DEFAULT_LAG_DAYS = 2;

    /** How often ss.systems fans the sync out to every managed site. */
    public const CADENCE = 'everyThreeHours';

    public const TIMEZONE = 'America/Chicago';

    /**
     * A site whose last successful sync is older than this many hours (twice
     * the cadence) reads as stale rather than "still due any minute now".
     */
    public const SYNCED_STALE_AFTER_HOURS = 6;
}
