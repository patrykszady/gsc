<?php

namespace SsSystems\Platform\Media;

use DateTimeInterface;
use Intervention\Image\Drivers\Gd\Driver;
use Intervention\Image\Encoders\JpegEncoder;
use Intervention\Image\ImageManager;

/**
 * The copy of a project photo that goes to Google Business Profile
 * (0.3.0, 2026-09-22): scaled to fit Google's fetch (it takes at most
 * 5 MB and fetches the URL itself), encoded as JPEG, and stamped with the
 * project's completion date and the market's coordinates — see
 * JpegExifTagger. One code path for every tenant: the central admin sends
 * the date and coordinates, the site calls this and serves the result.
 *
 * fingerprint() names the copy: the same source, date and place give the
 * same name, so a copy is made once and re-made only when one of them
 * changes.
 */
final class GooglePhotoCopy
{
    public const MAX_EDGE = 2400;

    public const QUALITY = 88;

    /** @return string JPEG bytes */
    public static function make(string $sourceBytes, ?float $latitude, ?float $longitude, ?DateTimeInterface $takenAt): string
    {
        // Intervention Image v3 (gs.construction) reads with read() and
        // encodes with toJpeg(); v4 (jpeterson-design) renamed them to
        // decode() and encode(). One kit serves both, so it asks which.
        $manager = new ImageManager(new Driver());
        $image = method_exists($manager, 'read') ? $manager->read($sourceBytes) : $manager->decode($sourceBytes);
        $image = $image->scaleDown(width: self::MAX_EDGE, height: self::MAX_EDGE);
        $encoded = method_exists($image, 'toJpeg')
            ? $image->toJpeg(self::QUALITY)
            : $image->encode(new JpegEncoder(quality: self::QUALITY));

        return (new JpegExifTagger())->stamp((string) $encoded, $latitude, $longitude, $takenAt);
    }

    /** A short stable name for the copy of one source with one date and place. */
    public static function fingerprint(string $sourceKey, ?float $latitude, ?float $longitude, ?DateTimeInterface $takenAt): string
    {
        return substr(sha1(implode('|', [
            $sourceKey,
            $latitude === null ? '' : number_format($latitude, 5, '.', ''),
            $longitude === null ? '' : number_format($longitude, 5, '.', ''),
            $takenAt?->format('Y-m-d') ?? '',
            'v1',
        ])), 0, 12);
    }
}
