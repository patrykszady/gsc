<?php

namespace Hive\Platform\Reviews;

/**
 * Runs the Angi profile scraper (resources/scripts/scrape-angi-reviews.mjs)
 * and hands back what it read.
 *
 * Angi refuses headless Chromium, so the browser runs headed on a virtual
 * display (xvfb-run) unless headless is asked for. Cloudflare refuses some
 * addresses outright — every datacenter one — so the scraper tries this
 * server first and falls back to residential sessions, pinned to the US:
 * the pool's default exits (Brazil, Chile, Russia, measured 2026-09-21)
 * were refused by a US site just the same, which is what "blocked from the
 * backup connection too" meant on both sites for weeks.
 *
 * The one thing a site supplies that the package cannot know is where its
 * Node dependencies live: this script sits in vendor/, so puppeteer is
 * resolved through NODE_PATH pointing at the site's node_modules.
 */
final class AngiScraper
{
    public const DEFAULT_PROXY_REGION = 'us';

    public function __construct(
        private readonly string $brandName,
        private readonly string $chromeProfileDir,
        private readonly ?string $nodeModules = null,
        private readonly ?string $proxy = null,
        private readonly ?string $proxyRegion = self::DEFAULT_PROXY_REGION,
        private readonly bool $skipDirect = false,
        private readonly bool $headless = false,
        private readonly int $maxPages = 10,
        private readonly int $timeoutMs = 90000,
        private readonly string $node = 'node',
        private readonly string $xvfb = 'xvfb-run',
        private readonly string $screen = '1440x2400x24',
        private readonly ?string $script = null,
    ) {}

    /** The scraper that ships with the package. */
    public static function script(): string
    {
        return dirname(__DIR__, 2).'/resources/scripts/scrape-angi-reviews.mjs';
    }

    /** The shell command a run executes — exposed so a test can read it without a browser. */
    public function command(string $profileUrl, string $resultFile): string
    {
        $node = sprintf(
            '%s %s --url=%s --brand=%s --out=%s --max-pages=%d --timeout-ms=%d --profile-dir=%s --proxy-region=%s%s%s%s',
            escapeshellarg($this->node),
            escapeshellarg($this->script ?? self::script()),
            escapeshellarg($profileUrl),
            escapeshellarg($this->brandName),
            escapeshellarg($resultFile),
            max(1, $this->maxPages),
            max(10000, $this->timeoutMs),
            escapeshellarg($this->chromeProfileDir),
            escapeshellarg((string) $this->proxyRegion),
            $this->headless ? ' --headless' : '',
            ($this->proxy ?? '') !== '' ? ' --proxy='.escapeshellarg($this->proxy) : '',
            $this->skipDirect ? ' --skip-direct' : '',
        );

        return $this->headless
            ? $node
            : sprintf('%s -a --server-args=%s %s', escapeshellarg($this->xvfb), escapeshellarg('-screen 0 '.$this->screen), $node);
    }

    /**
     * Read the profile.
     *
     * Progress lines go to $onLine as they arrive. The result always carries
     * a 'reviews' list, and an 'error' code when the read did not work — see
     * explain() for the words.
     *
     * @return array<string, mixed>
     */
    public function run(string $profileUrl, ?callable $onLine = null): array
    {
        if (! is_file($this->script ?? self::script())) {
            return ['error' => 'scraper_missing', 'reviews' => []];
        }

        // xvfb-run merges the child's stderr into stdout, so the result comes
        // back through a file and stdout carries only progress.
        $resultFile = tempnam(sys_get_temp_dir(), 'angi-reviews-');
        @mkdir($this->chromeProfileDir, 0775, true);

        $env = getenv();
        if ($this->nodeModules !== null) {
            $inherited = (string) ($env['NODE_PATH'] ?? '');
            $env['NODE_PATH'] = $this->nodeModules.($inherited !== '' ? PATH_SEPARATOR.$inherited : '');
        }

        $descriptors = [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
        $process = proc_open($this->command($profileUrl, $resultFile), $descriptors, $pipes, null, $env);
        if (! is_resource($process)) {
            @unlink($resultFile);

            return ['error' => 'scraper_failed', 'reviews' => []];
        }

        fclose($pipes[0]);
        stream_set_blocking($pipes[1], false);
        stream_set_blocking($pipes[2], false);

        $open = [$pipes[1], $pipes[2]];

        while ($open) {
            $read = $open;
            $write = null;
            $except = null;
            if (stream_select($read, $write, $except, 1) === false) {
                break;
            }

            foreach ($read as $pipe) {
                $chunk = fread($pipe, 65536);
                if ($chunk === false || $chunk === '') {
                    if (feof($pipe)) {
                        $key = array_search($pipe, $open, true);
                        if ($key !== false) {
                            unset($open[$key]);
                        }
                    }

                    continue;
                }

                foreach (explode("\n", trim($chunk)) as $line) {
                    if ($line !== '' && $onLine !== null) {
                        $onLine($line);
                    }
                }
            }
        }

        fclose($pipes[1]);
        fclose($pipes[2]);
        proc_close($process);

        $decoded = json_decode((string) @file_get_contents($resultFile), true);
        @unlink($resultFile);

        return is_array($decoded) ? $decoded + ['reviews' => []] : ['error' => 'scraper_failed', 'reviews' => []];
    }

    /** What the Platforms card and the command say for each error code. */
    public static function explain(string $error, ?string $businessName, string $brandName): string
    {
        return match ($error) {
            'blocked' => 'Angi’s bot protection blocked the read, from this server and from the backup connection. It often works again on the next run.',
            'not_found' => 'Angi returned "page not found" for the profile URL — check it under Admin → Social Media.',
            'wrong_business' => 'That Angi page belongs to '.($businessName ?: 'another business').', not '.$brandName.'.',
            'brand_not_configured' => 'This site has no business name configured, so the Angi page could not be checked against one.',
            default => 'Angi’s profile page carried no review data.',
        };
    }
}
